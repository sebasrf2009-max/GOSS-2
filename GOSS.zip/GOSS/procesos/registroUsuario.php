<?php
session_start();

require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../datos/goss/gossDAO.php";
require_once __DIR__ . "/../logica/validarGoss.php";

$error = validarRegistroUsuario();

if ($error !== "") {
    header("Location: ../index.php?vista=registro&mensaje=" . urlencode($error));
    exit();
}

$nombreCompleto = normalizarEspacios(textoPost("nombreCompleto"));
$documento = textoPost("documentoRegistro");
$rolId = (int) textoPost("rolRegistro");
$password = password_hash(textoPost("passwordRegistro", false), PASSWORD_DEFAULT);

if (existeUsuarioPorDocumento($conexion, $documento)) {
    header("Location: ../index.php?vista=registro&mensaje=" . urlencode("Ya existe un usuario registrado con ese documento."));
    exit();
}

if (!insertarUsuario($conexion, $nombreCompleto, $documento, $rolId, $password, date("Y-m-d H:i:s"))) {
    header("Location: ../index.php?vista=registro&mensaje=" . urlencode("No fue posible crear el usuario. Verifique el rol seleccionado."));
    exit();
}

header("Location: ../index.php?vista=login&mensaje=" . urlencode("Usuario creado correctamente. Ya puede iniciar sesión."));
exit();
