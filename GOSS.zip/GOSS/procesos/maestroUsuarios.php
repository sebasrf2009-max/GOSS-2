<?php
session_start();
require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../datos/goss/gossDAO.php";
require_once __DIR__ . "/../logica/validarGoss.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST" || !isset($_SESSION["usuario_id"])) {
    http_response_code(403); exit("Acceso denegado.");
}
$uid = (int) $_SESSION["usuario_id"];
$stmt = $conexion->prepare("SELECT EsMaestro, EstadoCuenta FROM usuario WHERE UsuarioId = ?");
$stmt->bind_param("i", $uid);
$stmt->execute();
$me = $stmt->get_result()->fetch_assoc();
if (!$me || (int)$me["EsMaestro"] !== 1 || $me["EstadoCuenta"] !== "ACTIVO") {
    http_response_code(403); exit("Acceso denegado.");
}
$csrfSesion = $_SESSION["csrf_maestro"] ?? "";
$csrfPost = textoPost("csrf", false);
if (!is_string($csrfSesion) || $csrfSesion === "" || !hash_equals($csrfSesion, $csrfPost)) {
    http_response_code(403); exit("Solicitud no válida.");
}
$accion = textoPost("accion");

if ($accion === "guardar") {
    $targetTexto = textoPost("usuario_id");
    $target = $targetTexto === ""
        ? 0
        : filter_var($targetTexto, FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]]);

    if ($target === false || ($target !== 0 && $target === $uid)) {
        header("Location: ../index.php?vista=maestro&mensaje=" . urlencode("No puedes modificar esa cuenta desde este panel.")); exit();
    }

    if ($target !== 0) {
        $usuarioExistente = obtenerUsuarioEditable($conexion, $target);
        if (!$usuarioExistente || (int) $usuarioExistente["EsMaestro"] === 1) {
            header("Location: ../index.php?vista=maestro&mensaje=" . urlencode("Esa cuenta no se puede editar.")); exit();
        }
    }

    $nombreCompleto = normalizarEspacios(textoPost("nombreCompleto"));
    $documento = textoPost("documento");
    $rolIdTexto = textoPost("rol_id");
    $rolId = filter_var($rolIdTexto, FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]]);
    $password = textoPost("password", false);
    $volver = $target === 0 ? "" : "&editar=" . (int) $target;

    if (!nombreValido($nombreCompleto)) {
        header("Location: ../index.php?vista=maestro" . $volver . "&mensaje=" . urlencode("Escriba un nombre y apellido válidos.")); exit();
    }
    if (!documentoValido($documento)) {
        header("Location: ../index.php?vista=maestro" . $volver . "&mensaje=" . urlencode("El documento debe tener solo números, entre 6 y 10 dígitos.")); exit();
    }
    if ($rolId === false || !existeRol($conexion, $rolId)) {
        header("Location: ../index.php?vista=maestro" . $volver . "&mensaje=" . urlencode("Seleccione un rol válido.")); exit();
    }
    if (($target === 0 && $password === "") || ($password !== "" && !passwordValida($password))) {
        header("Location: ../index.php?vista=maestro" . $volver . "&mensaje=" . urlencode("La contraseña debe tener entre 8 y 72 caracteres, con al menos una letra y un número.")); exit();
    }
    if (existeDocumentoUsuarioExcepto($conexion, $documento, $target)) {
        header("Location: ../index.php?vista=maestro" . $volver . "&mensaje=" . urlencode("Ya existe un usuario registrado con ese documento.")); exit();
    }

    $passwordHash = $password === "" ? null : password_hash($password, PASSWORD_DEFAULT);
    if ($target === 0) {
        $ok = crearUsuarioDesdeMaestro($conexion, $nombreCompleto, $documento, $rolId, $passwordHash);
        $msg = $ok ? "Usuario creado correctamente." : "No fue posible crear el usuario.";
    } else {
        $ok = actualizarUsuarioDesdeMaestro($conexion, $target, $nombreCompleto, $documento, $rolId, $passwordHash);
        $msg = $ok ? "Usuario actualizado correctamente." : "No fue posible actualizar el usuario.";
    }

    header("Location: ../index.php?vista=maestro&mensaje=" . urlencode($msg));
    exit();
}

$target = filter_input(INPUT_POST, "usuario_id", FILTER_VALIDATE_INT);
if (!$target || $target === $uid) {
    header("Location: ../index.php?vista=maestro&mensaje=" . urlencode("No puedes modificar tu propia cuenta desde este panel.")); exit();
}
if (!in_array($accion, ["restringir", "activar", "eliminar"], true)) {
    header("Location: ../index.php?vista=maestro&mensaje=" . urlencode("Acción no válida.")); exit();
}
if ($accion === "restringir" || $accion === "activar") {
    $estado = $accion === "restringir" ? "RESTRINGIDO" : "ACTIVO";
    $q = $conexion->prepare("UPDATE usuario SET EstadoCuenta = ? WHERE UsuarioId = ? AND EsMaestro = 0");
    $q->bind_param("si", $estado, $target);
    $ok = $q->execute() && $q->affected_rows >= 0;
    $msg = $ok ? "Estado de la cuenta actualizado." : "No fue posible actualizar la cuenta.";
} else {
    // Borrado físico solo si no existen registros históricos relacionados.
    $q = $conexion->prepare("DELETE FROM usuario WHERE UsuarioId = ? AND EsMaestro = 0");
    $q->bind_param("i", $target);
    $ok = $q->execute() && $q->affected_rows === 1;
    $msg = $ok ? "Usuario eliminado." : "No se pudo eliminar: puede tener bitácoras u otros registros asociados. En ese caso, restríngele el acceso.";
}
header("Location: ../index.php?vista=maestro&mensaje=" . urlencode($msg));
exit();
