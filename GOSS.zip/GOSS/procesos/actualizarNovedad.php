<?php
session_start();

require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../datos/goss/gossDAO.php";
require_once __DIR__ . "/../logica/validarGoss.php";

if (!isset($_SESSION["usuario_id"]) || !in_array($_SESSION["rol"], ["Administrador", "Tecnico"], true)) {
    header("Location: ../index.php?mensaje=" . urlencode("Acceso no autorizado."));
    exit();
}

$bitacoraId = filter_var(textoPost("bitacoraId"), FILTER_VALIDATE_INT);
$equipoId = filter_var(textoPost("equipoId"), FILTER_VALIDATE_INT);
$estado = textoPost("estado");

if (!$bitacoraId || !$equipoId || !in_array($estado, estadosNovedad(), true)) {
    header("Location: ../index.php?vista=admin&mensaje=" . urlencode("Datos de actualización no válidos."));
    exit();
}

// Un técnico queda asignado a la novedad que actualiza.
$tecnicoId = $_SESSION["rol"] === "Tecnico" ? $_SESSION["usuario_id"] : null;

if (actualizarEstadoNovedad($conexion, $bitacoraId, $equipoId, $estado, $tecnicoId)) {
    sincronizarEstadoEquipo($conexion, $equipoId);
    $mensaje = "Estado actualizado correctamente.";
} else {
    $mensaje = "No fue posible actualizar el estado.";
}

header("Location: ../index.php?vista=admin&mensaje=" . urlencode($mensaje));
exit();
