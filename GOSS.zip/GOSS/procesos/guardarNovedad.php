<?php
session_start();

require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../datos/goss/gossDAO.php";
require_once __DIR__ . "/../logica/validarGoss.php";

if (!isset($_SESSION["usuario_id"])) {
    header("Location: ../index.php?vista=login&mensaje=" . urlencode("Debe iniciar sesión."));
    exit();
}

function volverANovedad($mensaje)
{
    header("Location: ../index.php?vista=novedad&mensaje=" . urlencode($mensaje));
    exit();
}

$bitacoras = listarBitacorasParaNovedad($conexion, $_SESSION["usuario_id"]);

if (count($bitacoras) === 0) {
    volverANovedad("Primero debe abrir una bitácora.");
}

$error = validarNovedad();

if ($error !== "") {
    volverANovedad($error);
}

// Solo se puede reportar sobre una bitácora propia de la lista.
$bitacora = null;

foreach ($bitacoras as $candidata) {
    if ((int) $candidata["BitacoraId"] === (int) textoPost("bitacoraId")) {
        $bitacora = $candidata;
    }
}

if ($bitacora === null) {
    volverANovedad("La bitácora seleccionada no es válida.");
}

// El equipo se busca dentro de la sala de la bitácora. Si todavía no está
// en el inventario de esa sala, se crea.
$codigo = normalizarCodigoEquipo(textoPost("equipo"));
$equipo = buscarEquipoPorCodigo($conexion, $codigo, (int) $bitacora["SalonId"]);

$equipoId = $equipo
    ? (int) $equipo["EquipoId"]
    : insertarEquipo($conexion, $codigo, nombreEquipoDesdeCodigo($codigo), (int) $bitacora["SalonId"]);

if ($equipoId === false) {
    volverANovedad("No fue posible registrar el equipo.");
}

if (existeNovedad($conexion, (int) $bitacora["BitacoraId"], $equipoId)) {
    volverANovedad("Ya se reportó una novedad para el equipo " . $codigo . " en esta bitácora.");
}

if (!insertarNovedad($conexion, (int) $bitacora["BitacoraId"], $equipoId, textoPost("descripcion"), textoPost("nivelDano"))) {
    volverANovedad("No fue posible registrar la novedad.");
}

sincronizarEstadoEquipo($conexion, $equipoId);

volverANovedad("Novedad registrada correctamente.");
