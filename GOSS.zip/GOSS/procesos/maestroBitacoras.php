<?php
session_start();

require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../datos/goss/gossDAO.php";
require_once __DIR__ . "/../logica/validarGoss.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST" || !isset($_SESSION["usuario_id"])) {
    http_response_code(403);
    exit("Acceso denegado.");
}

$usuarioId = (int) $_SESSION["usuario_id"];
$stmt = $conexion->prepare("SELECT EsMaestro, EstadoCuenta FROM usuario WHERE UsuarioId = ?");
if (!$stmt) {
    http_response_code(500);
    exit("No fue posible verificar los permisos.");
}
$stmt->bind_param("i", $usuarioId);
if (!$stmt->execute()) {
    http_response_code(500);
    exit("No fue posible verificar los permisos.");
}
$maestro = $stmt->get_result()->fetch_assoc();

if (!$maestro || (int) $maestro["EsMaestro"] !== 1 || $maestro["EstadoCuenta"] !== "ACTIVO") {
    http_response_code(403);
    exit("Acceso denegado.");
}

$csrfSesion = $_SESSION["csrf_maestro"] ?? "";
$csrfPost = textoPost("csrf", false);
if (!is_string($csrfSesion) || $csrfSesion === "" || !hash_equals($csrfSesion, $csrfPost)) {
    http_response_code(403);
    exit("Solicitud no válida.");
}

function volverABitacorasMaestro($mensaje, $bitacoraId = null)
{
    $url = "../index.php?vista=maestro";
    if ($bitacoraId !== null) {
        $url .= "&editar_bitacora=" . (int) $bitacoraId;
    }
    header("Location: " . $url . "&mensaje=" . urlencode($mensaje));
    exit();
}

$accion = textoPost("accion");
$bitacoraId = filter_var(
    textoPost("bitacora_id"),
    FILTER_VALIDATE_INT,
    ["options" => ["min_range" => 1]]
);

if ($bitacoraId === false) {
    volverABitacorasMaestro("Selecciona una bitácora válida.");
}

if ($accion === "eliminar") {
    $fotoSalida = eliminarBitacoraMaestro($conexion, $bitacoraId);

    if ($fotoSalida === false) {
        volverABitacorasMaestro("No fue posible eliminar la bitácora y sus novedades asociadas.");
    }

    $mensaje = "Bitácora y novedades asociadas eliminadas.";
    if (is_string($fotoSalida)
        && preg_match('~^uploads/salas/[A-Za-z0-9_-]+\.(png|jpg|webp)$~i', $fotoSalida) === 1) {
        $rutaFoto = __DIR__ . "/../" . $fotoSalida;
        if (is_file($rutaFoto) && !unlink($rutaFoto)) {
            error_log("No fue posible borrar la foto de salida de la bitácora " . $bitacoraId);
            $mensaje .= " No se pudo borrar el archivo de la foto.";
        }
    }

    volverABitacorasMaestro($mensaje);
}

if ($accion !== "guardar") {
    volverABitacorasMaestro("Acción no válida.");
}

$bitacora = obtenerBitacoraMaestro($conexion, $bitacoraId);
if (!$bitacora) {
    volverABitacorasMaestro("No se encontró la bitácora.", $bitacoraId);
}

$profesorId = filter_var(textoPost("profesor_id"), FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]]);
$responsableId = filter_var(textoPost("responsable_id"), FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]]);
$salonId = filter_var(textoPost("salon_id"), FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]]);
$curso = normalizarEspacios(textoPost("curso"));
$jornada = textoPost("jornada");
$fecha = textoPost("fecha");
$horaEntrada = textoPost("hora_entrada");
$horaSalidaTexto = textoPost("hora_salida");
$limpiaEntrada = textoPost("limpia_entrada");
$limpiaSalidaTexto = textoPost("limpia_salida");
$ordenSalidaTexto = textoPost("orden_salida");
$observaciones = textoPost("observaciones");

if ($profesorId === false || $responsableId === false || $salonId === false
    || !cursoValido($curso)
    || !in_array($jornada, jornadasPermitidas(), true)
    || !fechaBitacoraValida($fecha)
    || !horaBitacoraValida($horaEntrada)
    || !in_array($limpiaEntrada, ["0", "1"], true)
    || mb_strlen($observaciones) > 1000) {
    volverABitacorasMaestro("Revisa los datos de la bitácora; hay campos inválidos.", $bitacoraId);
}

$profesor = buscarUsuarioPorId($conexion, $profesorId);
$responsable = buscarUsuarioPorId($conexion, $responsableId);
if (!$profesor || $profesor["NombreRol"] !== "Profesor"
    || !$responsable || !in_array($responsable["NombreRol"], ["Tecnico", "Administrador"], true)) {
    volverABitacorasMaestro("El docente o el responsable seleccionado no tiene un rol válido.", $bitacoraId);
}

if (!existeSalon($conexion, $salonId)) {
    volverABitacorasMaestro("Selecciona un salón válido.", $bitacoraId);
}

$horaEntrada .= ":00";
$horaSalida = null;
if ($horaSalidaTexto !== "") {
    if (!horaBitacoraValida($horaSalidaTexto)) {
        volverABitacorasMaestro("La hora de salida no es válida.", $bitacoraId);
    }
    $horaSalida = $horaSalidaTexto . ":00";
    if ($horaSalida <= $horaEntrada) {
        volverABitacorasMaestro("La hora de salida debe ser posterior a la de entrada.", $bitacoraId);
    }
}

$limpiaSalida = $limpiaSalidaTexto === "" ? null : filter_var($limpiaSalidaTexto, FILTER_VALIDATE_INT);
$ordenSalida = $ordenSalidaTexto === "" ? null : filter_var($ordenSalidaTexto, FILTER_VALIDATE_INT);
if (($limpiaSalida !== null && !in_array((string) $limpiaSalida, ["0", "1"], true))
    || ($ordenSalida !== null && !in_array((string) $ordenSalida, ["0", "1"], true))) {
    volverABitacorasMaestro("Los valores de limpieza u orden de salida no son válidos.", $bitacoraId);
}

if ($bitacora["EstadoRegistro"] === "FINALIZADA"
    && ($horaSalida === null || $limpiaSalida === null || $ordenSalida === null || $bitacora["FechaFirma"] === null)) {
    volverABitacorasMaestro("Una bitácora finalizada debe conservar la hora, limpieza, orden y firma.", $bitacoraId);
}

$ok = actualizarBitacoraMaestro(
    $conexion,
    $bitacoraId,
    $profesorId,
    $responsableId,
    $salonId,
    $curso,
    $jornada,
    $fecha,
    $horaEntrada,
    $horaSalida,
    (int) $limpiaEntrada,
    $limpiaSalida,
    $ordenSalida,
    $observaciones
);

volverABitacorasMaestro(
    $ok ? "Bitácora actualizada correctamente." : "No fue posible actualizar la bitácora.",
    $bitacoraId
);
