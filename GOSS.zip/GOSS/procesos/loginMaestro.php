<?php
session_start();

require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../datos/goss/gossDAO.php";
require_once __DIR__ . "/../logica/validarGoss.php";

$documento = textoPost("documento");
$password = textoPost("password", false);

if ($documento === "" || $password === "" || !preg_match('/^[0-9]{6,20}$/', $documento)) {
    header("Location: ../index.php?vista=maestro&mensaje=" . urlencode("Credenciales incorrectas."));
    exit();
}

$usuario = buscarUsuario($conexion, $documento);
if (!$usuario || !password_verify($password, $usuario["Password"])) {
    header("Location: ../index.php?vista=maestro&mensaje=" . urlencode("Credenciales incorrectas."));
    exit();
}

$stmt = $conexion->prepare("SELECT EsMaestro, EstadoCuenta FROM usuario WHERE UsuarioId = ?");
$stmt->bind_param("i", $usuario["UsuarioId"]);
$stmt->execute();
$estado = $stmt->get_result()->fetch_assoc();

if (!$estado || (int)$estado["EsMaestro"] !== 1 || $estado["EstadoCuenta"] !== "ACTIVO") {
    header("Location: ../index.php?vista=maestro&mensaje=" . urlencode("Credenciales incorrectas o cuenta sin privilegios maestros."));
    exit();
}

session_regenerate_id(true);
$_SESSION["usuario_id"] = (int)$usuario["UsuarioId"];
$_SESSION["nombre"] = $usuario["NombreCompleto"];
$_SESSION["rol"] = $usuario["NombreRol"];
$_SESSION["es_maestro"] = 1;

header("Location: ../index.php?vista=maestro");
exit();
