<?php
session_start();

require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../datos/goss/gossDAO.php";

if (!isset($_SESSION["usuario_id"]) || $_SESSION["rol"] !== "Administrador") {
    header("Location: ../index.php?mensaje=" . urlencode("Acceso no autorizado."));
    exit();
}

$resultado = listarPlanillaMensual($conexion);

if (!$resultado) {
    header("Location: ../index.php?vista=admin&mensaje=" . urlencode("No fue posible generar la planilla."));
    exit();
}

function siNo($valor)
{
    if ($valor === null) {
        return "";
    }

    return (int) $valor === 1 ? "Sí" : "No";
}

header("Content-Type: text/csv; charset=UTF-8");
header("Content-Disposition: attachment; filename=planilla_goss_" . date("Y_m") . ".csv");

$salida = fopen("php://output", "w");

// BOM para que Excel reconozca las tildes.
fwrite($salida, "\xEF\xBB\xBF");

fputcsv($salida, [
    "Fecha", "Hora entrada", "Hora salida", "Docente", "Responsable", "Curso",
    "Salón", "Nivel educativo", "Limpia al entrar", "Limpia al salir",
    "Ordenado al salir", "Estado"
], ";", "\"", "\\");

while ($fila = $resultado->fetch_assoc()) {
    $fila["LimpiaEntrada"] = siNo($fila["LimpiaEntrada"]);
    $fila["LimpiaSalida"] = siNo($fila["LimpiaSalida"]);
    $fila["OrdenSalida"] = siNo($fila["OrdenSalida"]);

    fputcsv($salida, $fila, ";", "\"", "\\");
}

fclose($salida);
exit();
