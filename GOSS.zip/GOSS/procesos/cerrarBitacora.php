<?php
session_start();

require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../datos/goss/gossDAO.php";
require_once __DIR__ . "/../logica/validarGoss.php";
require_once __DIR__ . "/../logica/imagenesGoss.php";

if (!isset($_SESSION["usuario_id"])) {
    header("Location: ../index.php?vista=login&mensaje=" . urlencode("Debe iniciar sesión."));
    exit();
}

function volverABitacora($mensaje)
{
    header("Location: ../index.php?vista=bitacora&mensaje=" . urlencode($mensaje));
    exit();
}

// El cierre lo hace el docente porque es quien firma.
if ($_SESSION["rol"] !== "Profesor") {
    volverABitacora("Solo el docente puede cerrar y firmar la bitácora.");
}

$error = validarCierreBitacora();

if ($error !== "") {
    volverABitacora($error);
}

$usuarioId = $_SESSION["usuario_id"];
$bitacora = obtenerBitacoraAbierta($conexion, (int) textoPost("bitacoraId"), $usuarioId);

if (!$bitacora) {
    volverABitacora("La bitácora no existe o ya fue cerrada.");
}

$firmaActual = obtenerFirmaUsuario($conexion, $usuarioId);
$archivoFirma = $_FILES["firma"] ?? null;
$archivoFoto = $_FILES["fotoSalida"] ?? null;

$error = validarFirma($archivoFirma, $firmaActual === null);

if ($error === "") {
    $error = validarFotoSala($archivoFoto);
}

if ($error !== "") {
    volverABitacora($error);
}

$horaSalida = calcularHoraSalida($bitacora["Fecha"], $bitacora["HoraEntrada"]);

if ($horaSalida === null) {
    volverABitacora("La hora de cierre debe ser posterior a la hora de entrada.");
}

$fotoSalida = guardarImagenSubida($archivoFoto, "salas", "sala_" . $bitacora["BitacoraId"]);

if ($fotoSalida === false) {
    volverABitacora("No fue posible guardar la foto de la sala.");
}

// Si subió una firma nueva, reemplaza a la registrada.
if (is_array($archivoFirma) && $archivoFirma["error"] === UPLOAD_ERR_OK) {
    $rutaFirma = guardarImagenSubida($archivoFirma, "firmas", "firma_" . $usuarioId);

    if ($rutaFirma === false || !actualizarFirmaUsuario($conexion, $usuarioId, $rutaFirma)) {
        borrarImagenGuardada($fotoSalida);
        volverABitacora("No fue posible registrar la firma del docente.");
    }

    borrarImagenGuardada($firmaActual);
}

$cerrada = cerrarBitacora(
    $conexion,
    (int) $bitacora["BitacoraId"],
    $usuarioId,
    $horaSalida,
    (int) textoPost("limpiezaSalida"),
    (int) textoPost("ordenSalida"),
    textoPost("observaciones"),
    $fotoSalida,
    date("Y-m-d H:i:s")
);

if (!$cerrada) {
    borrarImagenGuardada($fotoSalida);
    volverABitacora("No fue posible cerrar la bitácora.");
}

volverABitacora("Bitácora cerrada y firmada correctamente.");
