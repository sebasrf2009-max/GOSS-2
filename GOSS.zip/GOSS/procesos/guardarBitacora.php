<?php
session_start();

require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../datos/goss/gossDAO.php";
require_once __DIR__ . "/../logica/validarGoss.php";

if (!isset($_SESSION["usuario_id"])) {
    header("Location: ../index.php?vista=login&mensaje=" . urlencode("Debe iniciar sesión."));
    exit();
}

function volverABitacora($mensaje)
{
    header("Location: ../index.php?vista=bitacora&mensaje=" . urlencode($mensaje));
    exit();
}

$error = validarBitacora();

if ($error !== "") {
    volverABitacora($error);
}

$usuarioId = $_SESSION["usuario_id"];
$participanteId = (int) textoPost("participante");
$salonId = (int) textoPost("salon");

// La bitácora siempre lleva un docente y un responsable (técnico o administrador).
// Quien está en sesión ocupa uno de los dos lugares y elige al otro.
$participante = buscarUsuarioPorId($conexion, $participanteId);

if (!$participante) {
    volverABitacora("La persona seleccionada no existe.");
}

if ($_SESSION["rol"] === "Profesor") {
    if (!in_array($participante["NombreRol"], ["Tecnico", "Administrador"], true)) {
        volverABitacora("El responsable debe ser un técnico o un administrador.");
    }

    $profesorId = $usuarioId;
    $responsableId = $participanteId;
} else {
    if ($participante["NombreRol"] !== "Profesor") {
        volverABitacora("Debe seleccionar un docente.");
    }

    $profesorId = $participanteId;
    $responsableId = $usuarioId;
}

if (!salonDisponible($conexion, $salonId)) {
    volverABitacora("El salón seleccionado no está disponible.");
}

$cursoId = obtenerOCrearCurso($conexion, normalizarEspacios(textoPost("curso")));

if ($cursoId === false) {
    volverABitacora("No fue posible registrar el curso.");
}

$bitacoraId = insertarBitacora(
    $conexion,
    $profesorId,
    $responsableId,
    $salonId,
    $cursoId,
    textoPost("jornada"),
    date("Y-m-d"),
    date("H:i:s"),
    (int) textoPost("limpiezaEntrada")
);

if ($bitacoraId === false) {
    volverABitacora("No fue posible abrir la bitácora.");
}

volverABitacora($_SESSION["rol"] === "Profesor"
    ? "Bitácora abierta. Al terminar la clase la cierra con la foto de la sala y su firma."
    : "Bitácora abierta. El docente la cierra y firma al terminar la clase.");
