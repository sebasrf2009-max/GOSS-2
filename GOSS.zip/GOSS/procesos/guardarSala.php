<?php
session_start();

require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../datos/goss/gossDAO.php";
require_once __DIR__ . "/../logica/validarGoss.php";

if (!isset($_SESSION["usuario_id"])) {
    header("Location: ../index.php?vista=login&mensaje=" . urlencode("Debe iniciar sesión."));
    exit();
}

// El registro de las salas lo mantienen el técnico y el administrador.
if (!in_array($_SESSION["rol"], ["Tecnico", "Administrador"], true)) {
    header("Location: ../index.php?vista=bitacora&mensaje=" . urlencode("No tiene permiso para modificar el registro de las salas."));
    exit();
}

function volverASala($salonId, $mensaje)
{
    $destino = $salonId > 0 ? "sala&id=" . $salonId : "salas";
    header("Location: ../index.php?vista=" . $destino . "&mensaje=" . urlencode($mensaje));
    exit();
}

$salonId = (int) textoPost("salonId");
$idsTipos = array_column(listarTiposElemento($conexion), "TipoElementoId");

$error = validarRegistroSala($idsTipos);

if ($error !== "") {
    volverASala($salonId, $error);
}

$salaExiste = false;

foreach (listarSalas($conexion) as $sala) {
    if ((int) $sala["SalonId"] === $salonId) {
        $salaExiste = true;
    }
}

if (!$salaExiste) {
    volverASala(0, "La sala seleccionada no existe.");
}

$guardada = guardarRegistroSala(
    $conexion,
    $salonId,
    leerValores("cantidad", $idsTipos),
    leerValores("danados", $idsTipos),
    (int) textoPost("limpia"),
    (int) textoPost("organizada"),
    textoPost("observacionesSala"),
    $_SESSION["usuario_id"],
    date("Y-m-d H:i:s")
);

volverASala($salonId, $guardada
    ? "Registro de la sala guardado correctamente."
    : "No fue posible guardar el registro de la sala.");
