<?php
session_start();

require_once __DIR__ . "/../config/conexionBDD.php";
require_once __DIR__ . "/../datos/goss/gossDAO.php";
require_once __DIR__ . "/../logica/validarGoss.php";

$error = validarLogin();

if ($error !== "") {
    header("Location: ../index.php?vista=login&mensaje=" . urlencode($error));
    exit();
}

$usuario = buscarUsuario($conexion, textoPost("documento"));

if (!$usuario || !password_verify(textoPost("password", false), $usuario["Password"])) {
    header("Location: ../index.php?vista=login&mensaje=" . urlencode("Usuario o contraseña incorrectos."));
    exit();
}

// Las cuentas restringidas no pueden iniciar sesión.
$stmtEstado = $conexion->prepare("SELECT EstadoCuenta, EsMaestro FROM usuario WHERE UsuarioId = ?");
$stmtEstado->bind_param("i", $usuario["UsuarioId"]);
$stmtEstado->execute();
$estadoCuenta = $stmtEstado->get_result()->fetch_assoc();

if (!$estadoCuenta || $estadoCuenta["EstadoCuenta"] !== "ACTIVO") {
    header("Location: ../index.php?vista=login&mensaje=" . urlencode("Tu cuenta está restringida. Contacta al administrador."));
    exit();
}

// Deja constancia de cuándo autorizó el tratamiento de datos (solo la primera vez).
registrarAutorizacionDatos($conexion, (int) $usuario["UsuarioId"], date("Y-m-d H:i:s"));

session_regenerate_id(true);

$_SESSION["usuario_id"] = (int) $usuario["UsuarioId"];
$_SESSION["nombre"] = $usuario["NombreCompleto"];
$_SESSION["rol"] = $usuario["NombreRol"];
$_SESSION["es_maestro"] = (int) $estadoCuenta["EsMaestro"];

header("Location: ../index.php?vista=bitacora");
exit();
