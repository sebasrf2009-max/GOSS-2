<?php
define("SERVIDOR", "localhost");
define("USUARIO", "root");
define("PASSWORD", "");
define("BASE_DATOS", "goss");

// Las horas de la bitácora se guardan con la hora de Colombia.
date_default_timezone_set("America/Bogota");
