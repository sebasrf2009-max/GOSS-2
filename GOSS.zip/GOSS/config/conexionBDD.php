<?php
require_once __DIR__ . "/config.php";

mysqli_report(MYSQLI_REPORT_OFF);

$conexion = new mysqli(SERVIDOR, USUARIO, PASSWORD, BASE_DATOS);

if ($conexion->connect_errno) {
    die("No fue posible conectar con la base de datos.");
}

$conexion->set_charset("utf8mb4");
