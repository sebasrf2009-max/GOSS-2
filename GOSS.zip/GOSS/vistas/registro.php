<section id="registro" class="section active">
    <h2 class="screen-title">Crear usuario</h2>
    <p class="screen-subtitle">Registro de un nuevo usuario en GOSS</p>

    <div class="card-auth">
        <form action="procesos/registroUsuario.php" method="post">
            <div class="input-field">
                <label for="nombreCompleto">Nombre completo</label>
                <input type="text" id="nombreCompleto" name="nombreCompleto" maxlength="100"
                       pattern="[\p{L}][\p{L}'’\-]*( [\p{L}'’\-]+)+"
                       title="Escriba su nombre y apellido, solo con letras."
                       oninput="soloLetras(this)" onblur="this.value = this.value.trim()"
                       autocomplete="name" required>
                <p class="form-help">Nombre y apellido, solo letras.</p>
            </div>

            <div class="input-field">
                <label for="documentoRegistro">Documento</label>
                <input type="text" id="documentoRegistro" name="documentoRegistro" inputmode="numeric"
                       pattern="[0-9]{6,10}" minlength="6" maxlength="10"
                       title="Solo números, entre 6 y 10 dígitos."
                       oninput="soloNumeros(this)" required>
                <p class="form-help">Solo números, entre 6 y 10 dígitos.</p>
            </div>

            <div class="input-field">
                <label for="rolRegistro">Rol</label>
                <select id="rolRegistro" name="rolRegistro" required>
                    <option value="">Seleccione un rol</option>
                    <?php if ($roles): ?>
                        <?php while ($rol = $roles->fetch_assoc()): ?>
                            <option value="<?= (int) $rol["RolId"] ?>">
                                <?= htmlspecialchars($rol["NombreRol"] === "Tecnico" ? "Técnico" : $rol["NombreRol"]) ?>
                            </option>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </select>
            </div>

            <div class="input-field">
                <label for="passwordRegistro">Contraseña</label>
                <input type="password" id="passwordRegistro" name="passwordRegistro"
                       minlength="8" maxlength="72" pattern="(?=.*\p{L})(?=.*[0-9]).{8,72}"
                       title="Mínimo 8 caracteres, con al menos una letra y un número."
                       autocomplete="new-password" required>
                <p class="form-help">Mínimo 8 caracteres, con al menos una letra y un número.</p>
            </div>

            <div class="input-field">
                <label for="confirmarPassword">Confirmar contraseña</label>
                <input type="password" id="confirmarPassword" name="confirmarPassword"
                       minlength="8" maxlength="72" autocomplete="new-password" required>
            </div>

            <?php require __DIR__ . "/tratamientoDatos.php"; ?>

            <div class="register-actions">
                <button class="btn-action" type="submit">Guardar usuario</button>
                <a class="btn-secondary" href="index.php?vista=login">Volver a iniciar sesión</a>
            </div>
        </form>
    </div>
</section>
