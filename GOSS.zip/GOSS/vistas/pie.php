<?php
// Pie de página con los derechos de autor. El año final se actualiza solo.
$anioActual = (int) date("Y");
$anios = $anioActual > 2026 ? "2026-" . $anioActual : "2026";
?>
<footer class="pie">
    <div class="pie-contenido">
        <p class="pie-titulo">GOSS - Gestión Operativa de la Sala de Sistemas</p>
        <p>Colegio Técnico Palermo IED · SENA, Centro de Diseño y Metrología · Bogotá D.C.</p>
        <p>Proyecto productivo del Técnico en Programación de Software, desarrollado por Juan Sebastián Rojas Farfán.</p>
        <p class="pie-derechos">
            &copy; <?= $anios ?> GOSS. Todos los derechos reservados.
            Los logotipos del Colegio Técnico Palermo IED y del SENA pertenecen a sus respectivos titulares.
        </p>
        <p class="pie-derechos">Tratamiento de datos personales conforme a la Ley 1581 de 2012.</p>
    </div>
</footer>
