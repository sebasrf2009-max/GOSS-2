function setToggle(campo, valor) {
    const si = document.getElementById("lbl-" + campo + "-si");
    const no = document.getElementById("lbl-" + campo + "-no");
    const input = document.getElementById("val-" + campo);

    si.classList.toggle("selected-si", valor);
    no.classList.toggle("selected-no", !valor);
    input.value = valor ? "1" : "0";
}

function confirmarEstado() {
    return confirm("¿Desea actualizar el estado de esta novedad?");
}

// Muestra en la apertura de la bitácora lo que contiene la sala elegida.
function mostrarInfoSala(select) {
    document.querySelectorAll(".info-sala").forEach(function (bloque) {
        bloque.hidden = true;
    });

    const bloque = document.getElementById("info-sala-" + select.value);
    if (bloque) bloque.hidden = false;
}

// ---------- Tratamiento de datos personales (cuadro explicativo)

function abrirDatos() {
    const dialogo = document.getElementById("dialogo-datos");

    if (typeof dialogo.showModal === "function") {
        dialogo.showModal();
    } else {
        dialogo.setAttribute("open", "");
    }
}

function cerrarDatos() {
    const dialogo = document.getElementById("dialogo-datos");

    if (typeof dialogo.close === "function") {
        dialogo.close();
    } else {
        dialogo.removeAttribute("open");
    }
}

// Solo queda marcada la casilla si la persona acepta dentro del cuadro.
function aceptarDatos() {
    document.getElementById("aceptaDatos").checked = true;
    cerrarDatos();
}

// ---------- Restricciones al escribir (el servidor las vuelve a validar)

// Documento: solo dígitos.
function soloNumeros(input) {
    input.value = input.value.replace(/\D/g, "");
}

// Nombres: solo letras, espacios, apóstrofo y guion; sin espacios dobles.
function soloLetras(input) {
    input.value = input.value
        .replace(/[^\p{L}'’\- ]/gu, "")
        .replace(/^ +/, "")
        .replace(/ {2,}/g, " ");
}

// Código de equipo: letras, números, guion y guion bajo.
function soloCodigo(input) {
    input.value = input.value.replace(/[^A-Za-z0-9_\-]/g, "");
}

// Campos numéricos: evita escribir e, +, -, punto o coma.
function bloquearNoEnteros(evento) {
    if (["e", "E", "+", "-", ".", ","].includes(evento.key)) {
        evento.preventDefault();
    }
}

// Los dañados no pueden ser más que los que hay: el máximo sigue a la cantidad.
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll("input[data-max-de]").forEach(function (campo) {
        const origen = document.getElementById(campo.dataset.maxDe);

        if (!origen) return;

        const ajustar = function () {
            campo.max = origen.value === "" ? 999 : origen.value;
        };

        origen.addEventListener("input", ajustar);
        ajustar();
    });
});
