<section id="novedades-reporte" class="section active">
    <h2 class="screen-title">Reportar daño</h2>
    <p class="screen-subtitle">Registro de novedades técnicas</p>

    <div class="form-container">
        <?php if (count($bitacorasNovedad) === 0): ?>
            <p class="form-help">Primero debe abrir una bitácora para poder reportar un daño.</p>
            <a class="btn-action" style="display:inline-block;text-decoration:none;margin-top:0;"
               href="index.php?vista=bitacora">
                Ir a la bitácora
            </a>
        <?php else: ?>
            <form action="procesos/guardarNovedad.php" method="post">
                <div class="input-field">
                    <label for="bitacoraId">Bitácora del reporte</label>
                    <select id="bitacoraId" name="bitacoraId" required>
                        <?php foreach ($bitacorasNovedad as $bitacora): ?>
                            <option value="<?= (int) $bitacora["BitacoraId"] ?>">
                                N.º <?= (int) $bitacora["BitacoraId"] ?> -
                                <?= htmlspecialchars($bitacora["Fecha"]) ?> -
                                <?= htmlspecialchars($bitacora["Curso"]) ?>
                                (<?= htmlspecialchars($bitacora["Salon"]) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="form-help">El equipo se busca dentro del salón de esa bitácora.</p>
                </div>

                <div class="grid-form">
                    <div class="input-field">
                        <label for="equipo">Equipo afectado</label>
                        <input type="text" id="equipo" name="equipo" maxlength="50"
                               pattern="[A-Za-z0-9_\-]{1,50}"
                               title="Solo letras, números y guiones (sin espacios)."
                               oninput="soloCodigo(this)"
                               placeholder="Ejemplo: PC-01 o número de equipo" required>
                    </div>

                    <div class="input-field">
                        <label for="nivelDano">Nivel de daño</label>
                        <select id="nivelDano" name="nivelDano" required>
                            <option value="">Seleccione el nivel de daño</option>
                            <?php foreach (nivelesDano() as $valor => $texto): ?>
                                <option value="<?= htmlspecialchars($valor) ?>"><?= htmlspecialchars($texto) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="input-field">
                    <label for="descripcion">Descripción de la falla</label>
                    <textarea id="descripcion" name="descripcion" rows="5" minlength="5" maxlength="1000"
                              placeholder="Describa de forma clara la falla encontrada."
                              required></textarea>
                </div>

                <button class="btn-action btn-danger" type="submit" style="width:100%;">
                    Enviar reporte técnico
                </button>
            </form>
        <?php endif; ?>
    </div>
</section>
