<?php
// Lista de usuarios registrados. Solo la ve el administrador (ver index.php).
$etiquetasRol = ["Profesor" => "Docente", "Tecnico" => "Técnico", "Administrador" => "Administrador"];

$conteo = ["Profesor" => 0, "Tecnico" => 0, "Administrador" => 0];

foreach ($usuarios as $usuario) {
    if (isset($conteo[$usuario["NombreRol"]])) {
        $conteo[$usuario["NombreRol"]]++;
    }
}
?>
<section id="usuarios-lista" class="section active">
    <h2 class="screen-title">Usuarios</h2>
    <p class="screen-subtitle">Personas registradas en GOSS</p>

    <div class="admin-dashboard">
        <div class="stat-card">
            <h3>Total de usuarios</h3>
            <div class="stat-number"><?= count($usuarios) ?></div>
        </div>

        <?php foreach ($conteo as $rolNombre => $total): ?>
            <div class="stat-card">
                <h3><?= htmlspecialchars($etiquetasRol[$rolNombre]) ?><?= $rolNombre === "Administrador" ? "es" : "s" ?></h3>
                <div class="stat-number"><?= $total ?></div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="form-container" style="margin-top:30px;">
        <h3 class="form-titulo">Usuarios registrados</h3>

        <?php if (count($usuarios) === 0): ?>
            <p class="form-help">Todavía no hay usuarios registrados.</p>
        <?php else: ?>
            <div class="table-wrapper">
                <table class="table-logs">
                    <thead>
                        <tr>
                            <th>N.º</th>
                            <th>Nombre completo</th>
                            <th>Documento</th>
                            <th>Rol</th>
                            <th>Firma digital</th>
                            <th>Autorizó el tratamiento de datos</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($usuarios as $usuario): ?>
                            <tr>
                                <td><?= (int) $usuario["UsuarioId"] ?></td>
                                <td><?= htmlspecialchars($usuario["NombreCompleto"]) ?></td>
                                <td><?= htmlspecialchars($usuario["Documento"]) ?></td>
                                <td><?= htmlspecialchars($etiquetasRol[$usuario["NombreRol"]] ?? $usuario["NombreRol"]) ?></td>
                                <td><?= (int) $usuario["TieneFirma"] === 1 ? "Registrada" : "Sin registrar" ?></td>
                                <td><?= $usuario["FechaAutorizacionDatos"] !== null ? htmlspecialchars($usuario["FechaAutorizacionDatos"]) : "Sin registrar" ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</section>
