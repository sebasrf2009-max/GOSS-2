<?php
require_once __DIR__ . "/componentes.php";

$salaId = (int) $salaActual["SalonId"];
$registrada = $salaActual["FechaActualizacion"] !== null;
?>
<section id="sala-registro" class="section active">
    <h2 class="screen-title"><?= htmlspecialchars($salaActual["Nombre"]) ?></h2>
    <p class="screen-subtitle">Registro de la sala</p>

    <div class="form-container">
        <p class="form-help">
            <?php if (!$registrada): ?>
                Esta sala todavía no tiene registro. Complete lo que contiene y su estado.
            <?php else: ?>
                Último registro: <?= htmlspecialchars($salaActual["FechaActualizacion"]) ?><?= !empty($salaActual["ActualizadoPor"]) ? " por " . htmlspecialchars($salaActual["ActualizadoPor"]) : "" ?>.
                Si algo cambia, edítelo y guarde de nuevo.
            <?php endif; ?>
        </p>

        <form action="procesos/guardarSala.php" method="post">
            <input type="hidden" name="salonId" value="<?= $salaId ?>">

            <h3 class="form-titulo">Lo que contiene la sala</h3>

            <div class="grid-form">
                <?php foreach ($tiposElemento as $tipo): ?>
                    <?php $tipoId = (int) $tipo["TipoElementoId"]; ?>
                    <div class="input-field">
                        <label for="cantidad-<?= $tipoId ?>"><?= htmlspecialchars($tipo["Nombre"]) ?></label>
                        <input type="number" id="cantidad-<?= $tipoId ?>" name="cantidad[<?= $tipoId ?>]"
                               min="0" max="999" step="1" inputmode="numeric"
                               onkeydown="bloquearNoEnteros(event)" required
                               value="<?= isset($inventarioSalas[$salaId][$tipoId]) ? $inventarioSalas[$salaId][$tipoId]["cantidad"] : "" ?>">
                    </div>
                <?php endforeach; ?>
            </div>

            <h3 class="form-titulo">Equipos dañados</h3>
            <p class="form-help">
                Indique cuántos de cada tipo están dañados (PC, teclado, mouse, televisor o proyector).
                Deje 0 en los que no tengan daño.
            </p>

            <div class="grid-form">
                <?php foreach ($tiposElemento as $tipo): ?>
                    <?php $tipoId = (int) $tipo["TipoElementoId"]; ?>
                    <div class="input-field">
                        <label for="danados-<?= $tipoId ?>"><?= htmlspecialchars($tipo["Nombre"]) ?> dañados</label>
                        <input type="number" id="danados-<?= $tipoId ?>" name="danados[<?= $tipoId ?>]"
                               min="0" max="999" step="1" inputmode="numeric"
                               data-max-de="cantidad-<?= $tipoId ?>"
                               onkeydown="bloquearNoEnteros(event)" required
                               value="<?= isset($inventarioSalas[$salaId][$tipoId]) ? $inventarioSalas[$salaId][$tipoId]["danados"] : 0 ?>">
                    </div>
                <?php endforeach; ?>
            </div>

            <h3 class="form-titulo">Estado de la sala</h3>

            <div class="grid-form">
                <?php selectorSiNo("limpia", "¿La sala está limpia?", null, $registrada ? (int) $salaActual["Limpia"] : 1); ?>
                <?php selectorSiNo("organizada", "¿La sala está organizada?", null, $registrada ? (int) $salaActual["Organizada"] : 1); ?>
            </div>

            <div class="input-field">
                <label for="observacionesSala">Observaciones</label>
                <textarea id="observacionesSala" name="observacionesSala" rows="4" maxlength="1000"
                          placeholder="Ejemplo: dos mouse en reparación, un proyector sin control."><?= htmlspecialchars($salaActual["ObservacionesRegistro"] ?? "") ?></textarea>
            </div>

            <div class="register-actions">
                <button class="btn-action" type="submit">Guardar registro</button>
                <a class="btn-secondary" href="index.php?vista=salas">Volver a las salas</a>
            </div>
        </form>
    </div>
</section>
