<section id="login" class="section active">
    <h2 class="screen-title">Autenticación</h2>
    <p class="screen-subtitle">Proyecto Productivo - Sebastian Rojas</p>

    <div class="card-auth">
        <form action="procesos/login.php" method="post">
            <div class="input-field">
                <label for="documento">Documento</label>
                <input type="text" id="documento" name="documento" inputmode="numeric"
                       pattern="[0-9]+" maxlength="20" title="Solo números"
                       oninput="soloNumeros(this)" autocomplete="username"
                       placeholder="Número de documento" required>
            </div>

            <div class="input-field">
                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password"
                       placeholder="Contraseña" required>
            </div>

            <?php require __DIR__ . "/tratamientoDatos.php"; ?>

            <button class="btn-action" type="submit" style="width:100%;">
                Iniciar sesión
            </button>
        </form>

        <div class="auth-divider"><span>o</span></div>

        <a class="btn-secondary" href="index.php?vista=registro">Crear usuario</a>
    </div>
</section>
