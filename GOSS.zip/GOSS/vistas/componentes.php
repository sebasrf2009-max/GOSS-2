<?php

// Selector Sí / No que guarda 1 o 0 en un campo oculto (ver setToggle en goss.js).
function selectorSiNo($campo, $etiqueta, $nombre = null, $valor = 1)
{
    $nombre = $nombre ?? $campo;
    ?>
    <div class="input-field">
        <label><?= $etiqueta ?></label>
        <div class="status-selector">
            <div class="radio-btn <?= $valor ? "selected-si" : "" ?>" id="lbl-<?= $campo ?>-si"
                 onclick="setToggle('<?= $campo ?>', true)">Sí</div>
            <div class="radio-btn <?= $valor ? "" : "selected-no" ?>" id="lbl-<?= $campo ?>-no"
                 onclick="setToggle('<?= $campo ?>', false)">No</div>
        </div>
        <input type="hidden" id="val-<?= $campo ?>" name="<?= $nombre ?>" value="<?= $valor ? 1 : 0 ?>">
    </div>
    <?php
}
