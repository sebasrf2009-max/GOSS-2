<?php
require_once __DIR__ . "/componentes.php";

$esProfesor = $_SESSION["rol"] === "Profesor";
?>
<section id="bitacora-registro" class="section active">
    <h2 class="screen-title">Registro diario</h2>
    <p class="screen-subtitle">Control del estado de la sala de sistemas</p>

    <div class="form-container">
        <h3 class="form-titulo">Apertura de la bitácora</h3>

        <form action="procesos/guardarBitacora.php" method="post">
            <div class="grid-form">
                <div class="input-field">
                    <label for="curso">Curso responsable</label>
                    <input type="text" id="curso" name="curso" maxlength="100" minlength="2"
                           pattern="[\p{L}\p{N} .,\-\(\)\/°º]{2,100}"
                           title="Letras, números y los signos . , - ( ) /"
                           list="lista-cursos" placeholder="Ejemplo: 1001" required>
                    <datalist id="lista-cursos">
                        <?php while ($curso = $cursos->fetch_assoc()): ?>
                            <option value="<?= htmlspecialchars($curso["Nombre"]) ?>">
                        <?php endwhile; ?>
                    </datalist>
                </div>

                <div class="input-field">
                    <label for="jornada">Nivel educativo</label>
                    <select id="jornada" name="jornada" required>
                        <option value="">Seleccione el nivel educativo</option>
                        <?php foreach (jornadasPermitidas() as $jornada): ?>
                            <option value="<?= htmlspecialchars($jornada) ?>"><?= htmlspecialchars($jornada) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="grid-form">
                <div class="input-field">
                    <label for="salon">Salón</label>
                    <select id="salon" name="salon" required onchange="mostrarInfoSala(this)">
                        <option value="">Seleccione el salón</option>
                        <?php foreach ($salas as $sala): ?>
                            <?php if ($sala["Estado"] === "DISPONIBLE"): ?>
                                <option value="<?= (int) $sala["SalonId"] ?>"><?= htmlspecialchars($sala["Nombre"]) ?></option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="input-field">
                    <label for="participante">
                        <?= $esProfesor ? "Responsable de la sala" : "Docente a cargo" ?>
                    </label>
                    <select id="participante" name="participante" required>
                        <option value="">
                            <?= $esProfesor ? "Seleccione al técnico o administrador" : "Seleccione al docente" ?>
                        </option>
                        <?php while ($persona = $participantes->fetch_assoc()): ?>
                            <option value="<?= (int) $persona["UsuarioId"] ?>">
                                <?= htmlspecialchars($persona["NombreCompleto"]) ?>
                                (<?= htmlspecialchars($persona["NombreRol"] === "Tecnico" ? "Técnico" : $persona["NombreRol"]) ?>)
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <?php selectorSiNo("limpiezaEntrada", "¿El aula se recibe limpia?"); ?>
            </div>

            <?php foreach ($salas as $sala): ?>
                <?php if ($sala["Estado"] === "DISPONIBLE"): ?>
                    <div class="info-sala" id="info-sala-<?= (int) $sala["SalonId"] ?>" hidden>
                        <h4 class="info-sala-titulo">Lo que contiene <?= htmlspecialchars($sala["Nombre"]) ?></h4>
                        <?php include __DIR__ . "/resumenSala.php"; ?>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>

            <button class="btn-action" type="submit" style="width:100%;">
                Abrir bitácora
            </button>
        </form>
    </div>

    <?php if ($esProfesor): ?>
        <div class="form-container">
            <h3 class="form-titulo">Cierre y firma</h3>

            <?php if (count($bitacorasAbiertas) > 0): ?>
                <form action="procesos/cerrarBitacora.php" method="post" enctype="multipart/form-data">
                    <div class="input-field">
                        <label for="bitacoraId">Bitácora abierta</label>
                        <select id="bitacoraId" name="bitacoraId" required>
                            <?php foreach ($bitacorasAbiertas as $abierta): ?>
                                <option value="<?= (int) $abierta["BitacoraId"] ?>">
                                    N.º <?= (int) $abierta["BitacoraId"] ?> -
                                    <?= htmlspecialchars($abierta["Fecha"]) ?>
                                    <?= htmlspecialchars(substr($abierta["HoraEntrada"], 0, 5)) ?> -
                                    <?= htmlspecialchars($abierta["Curso"]) ?>
                                    (<?= htmlspecialchars($abierta["Salon"]) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="grid-form">
                        <?php selectorSiNo("limpiezaSalida", "¿El aula se entrega limpia?"); ?>
                        <?php selectorSiNo("ordenSalida", "¿El mobiliario está ordenado?"); ?>
                    </div>

                    <div class="input-field">
                        <label for="observaciones">Observaciones</label>
                        <textarea id="observaciones" name="observaciones" rows="4" maxlength="1000"
                                  placeholder="Registre alguna observación de la sala."></textarea>
                    </div>

                    <div class="input-field">
                        <label for="fotoSalida">Foto de cómo queda la sala</label>
                        <input type="file" id="fotoSalida" name="fotoSalida"
                               accept="image/png,image/jpeg,image/webp" required>
                        <p class="form-help">
                            Tome o suba una foto de la sala antes de salir. Máximo 8 MB.
                        </p>
                    </div>

                    <div class="input-field">
                        <label for="firma">Firma del docente</label>

                        <?php if ($firmaActual): ?>
                            <img class="firma-preview" src="<?= htmlspecialchars($firmaActual) ?>"
                                 alt="Firma registrada del docente">
                            <input type="file" id="firma" name="firma"
                                   accept="image/png,image/jpeg,image/webp">
                            <p class="form-help">
                                Se usará la firma registrada. Suba otra imagen solo si desea reemplazarla.
                            </p>
                        <?php else: ?>
                            <input type="file" id="firma" name="firma"
                                   accept="image/png,image/jpeg,image/webp" required>
                            <p class="form-help">
                                Suba una imagen clara de su firma. Quedará registrada para las próximas bitácoras.
                            </p>
                        <?php endif; ?>
                    </div>

                    <button class="btn-action" type="submit" style="width:100%;">
                        Cerrar bitácora
                    </button>
                </form>
            <?php else: ?>
                <p class="form-help">No tiene bitácoras abiertas pendientes de cierre.</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</section>
