<?php
$meses = [
    "ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO",
    "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"
];
?>
<section id="admin-panel" class="section active">
    <h2 class="screen-title"><?= $_SESSION["rol"] === "Administrador" ? "Administración" : "Novedades" ?></h2>
    <p class="screen-subtitle">Historial y estado de la sala</p>

    <div class="admin-dashboard">
        <div class="stat-card operativo">
            <h3>Equipos disponibles</h3>
            <div class="stat-number"><?= $equiposSalas["disponibles"] ?> / <?= $equiposSalas["total"] ?></div>
            <p>
                <?php if ($equiposSalas["total"] === 0): ?>
                    Aún no hay equipos registrados en las salas.
                <?php else: ?>
                    Según el registro de las salas. Dañados: <?= $equiposSalas["danados"] ?>.
                <?php endif; ?>
            </p>
        </div>

        <div class="stat-card critico">
            <h3>Novedades de daño</h3>
            <div class="stat-number"><?= array_sum($novedadesPorNivel) ?></div>
            <p>Sin solucionar, de cualquier nivel.</p>
            <ul class="niveles-lista">
                <?php foreach ($novedadesPorNivel as $nivel => $total): ?>
                    <li>
                        <span><?= htmlspecialchars(nivelesDano()[$nivel]) ?></span>
                        <strong><?= $total ?></strong>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <?php if ($_SESSION["rol"] === "Administrador"): ?>
            <div class="stat-card">
                <h3>Planilla mensual</h3>
                <div class="stat-number" style="font-size:1.2rem;">
                    <?= $meses[(int) date("n") - 1] . " " . date("Y") ?>
                </div>
                <a class="btn-action" style="display:inline-block;text-decoration:none;font-size:.8rem;padding:8px 14px;"
                   href="procesos/generarPlanilla.php">
                    Exportar
                </a>
            </div>
        <?php endif; ?>
    </div>

    <div class="form-container" style="margin-top:30px;">
        <h3 style="font-family:'Oswald';font-size:1.5rem;color:var(--amarillo-alerta);">
            Historial de novedades
        </h3>

        <div class="table-wrapper">
            <table class="table-logs">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Salón</th>
                        <th>Equipo</th>
                        <th>Nivel</th>
                        <th>Descripción</th>
                        <th>Curso</th>
                        <th>Docente</th>
                        <th>Técnico</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($novedad = $novedades->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($novedad["FechaReporte"]) ?></td>
                            <td><?= htmlspecialchars($novedad["Salon"]) ?></td>
                            <td><?= htmlspecialchars($novedad["CodigoInventario"]) ?></td>
                            <td><?= htmlspecialchars(nivelesDano()[$novedad["NivelDano"]] ?? $novedad["NivelDano"]) ?></td>
                            <td><?= htmlspecialchars($novedad["DescripcionFalla"]) ?></td>
                            <td><?= htmlspecialchars($novedad["Curso"]) ?></td>
                            <td><?= htmlspecialchars($novedad["Profesor"]) ?></td>
                            <td><?= htmlspecialchars($novedad["Tecnico"] ?? "Sin asignar") ?></td>
                            <td>
                                <form class="actions" action="procesos/actualizarNovedad.php"
                                      method="post" onsubmit="return confirmarEstado();">
                                    <input type="hidden" name="bitacoraId" value="<?= (int) $novedad["BitacoraId"] ?>">
                                    <input type="hidden" name="equipoId" value="<?= (int) $novedad["EquipoId"] ?>">
                                    <select name="estado">
                                        <?php foreach (estadosNovedad() as $estado): ?>
                                            <option value="<?= htmlspecialchars($estado) ?>"
                                                <?= $estado === $novedad["EstadoNovedad"] ? "selected" : "" ?>>
                                                <?= htmlspecialchars($estado) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" class="btn-action" style="margin:0;padding:6px 10px;font-size:.7rem;">
                                        Guardar
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if ($_SESSION["rol"] === "Administrador"): ?>
        <div class="form-container" style="margin-top:30px;">
            <h3 style="font-family:'Oswald';font-size:1.5rem;color:var(--amarillo-alerta);">
                Bitácoras recientes
            </h3>

            <div class="table-wrapper">
                <table class="table-logs">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Horario</th>
                            <th>Salón</th>
                            <th>Curso</th>
                            <th>Docente</th>
                            <th>Responsable</th>
                            <th>Estado</th>
                            <th>Foto de salida</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bitacorasRecientes as $bitacora): ?>
                            <tr>
                                <td><?= htmlspecialchars($bitacora["Fecha"]) ?></td>
                                <td>
                                    <?= htmlspecialchars(substr($bitacora["HoraEntrada"], 0, 5)) ?>
                                    - <?= $bitacora["HoraSalida"] ? htmlspecialchars(substr($bitacora["HoraSalida"], 0, 5)) : "abierta" ?>
                                </td>
                                <td><?= htmlspecialchars($bitacora["Salon"]) ?></td>
                                <td><?= htmlspecialchars($bitacora["Curso"]) ?></td>
                                <td><?= htmlspecialchars($bitacora["Profesor"]) ?></td>
                                <td><?= htmlspecialchars($bitacora["Responsable"]) ?></td>
                                <td><?= htmlspecialchars(ucfirst(strtolower($bitacora["EstadoRegistro"]))) ?></td>
                                <td>
                                    <?php if ($bitacora["FotoSalida"]): ?>
                                        <a href="<?= htmlspecialchars($bitacora["FotoSalida"]) ?>" target="_blank" rel="noopener"
                                           style="color:var(--amarillo-alerta);">Ver foto</a>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</section>
