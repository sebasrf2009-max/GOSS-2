<section id="salas-lista" class="section active">
    <h2 class="screen-title">Salas de sistemas</h2>
    <p class="screen-subtitle">Lo que contiene y el estado de cada sala</p>

    <div class="salas-grid">
        <?php foreach ($salas as $sala): ?>
            <div class="sala-card">
                <h3><?= htmlspecialchars($sala["Nombre"]) ?></h3>

                <?php include __DIR__ . "/resumenSala.php"; ?>

                <a class="btn-action" style="display:inline-block;text-decoration:none;"
                   href="index.php?vista=sala&id=<?= (int) $sala["SalonId"] ?>">
                    <?= $sala["FechaActualizacion"] === null ? "Registrar sala" : "Ver y editar" ?>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
</section>
