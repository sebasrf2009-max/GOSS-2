<nav id="main-nav">
    <div class="nav-brand">
        <img src="vistas/img/logo-palermo.png"
             class="logo-img" alt="Logo Colegio Técnico Palermo IED">
        <h1 style="font-family:'Oswald';font-size:1.2rem;">GOSS - BITÁCORA DIGITAL</h1>
    </div>

    <div class="nav-links">
        <?php if ($_SESSION["rol"] === "Administrador"): ?>
            <a href="index.php?vista=admin">Administración</a>
            <a href="index.php?vista=usuarios">Usuarios</a>
        <?php elseif ($_SESSION["rol"] === "Tecnico"): ?>
            <a href="index.php?vista=admin">Novedades</a>
        <?php endif; ?>

        <?php if (in_array($_SESSION["rol"], ["Administrador", "Tecnico"], true)): ?>
            <a href="index.php?vista=salas">Salas</a>
        <?php endif; ?>

        <a href="index.php?vista=bitacora">Bitácora</a>
        <a href="index.php?vista=novedad">Reportar daño</a>
        <a href="procesos/logout.php">Salir</a>
    </div>
</nav>
