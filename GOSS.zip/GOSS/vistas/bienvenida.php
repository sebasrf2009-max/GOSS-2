<section id="welcome-screen" class="section active">
    <div class="welcome-box">
        <h2 class="screen-title" style="font-size: 3.5rem;">Sistema GOSS</h2>
        <p class="screen-subtitle" style="color: var(--verde-sena);">
            Control y optimización de la sala de sistemas
        </p>
        <p style="font-size:1.05rem;line-height:1.6;color:#e2e8f0;text-align:justify;">
            Bienvenido al aplicativo web de Gestión Operativa de la Sala de Sistemas
            del Colegio Técnico Palermo IED. GOSS centraliza el registro de bitácoras,
            novedades y mantenimiento para conservar la trazabilidad del aula.
        </p>
        <a href="index.php?vista=login" class="btn-action" style="display:inline-block;text-decoration:none;">
            Ingresar al sistema
        </a>
    </div>
</section>
