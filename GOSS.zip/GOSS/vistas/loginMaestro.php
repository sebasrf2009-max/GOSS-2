<section id="login-maestro" class="section active">
    <h2 class="screen-title">Acceso maestro</h2>
    <p class="screen-subtitle">Área privada de administración</p>
    <div class="card-auth">
        <form action="procesos/loginMaestro.php" method="post" autocomplete="on">
            <div class="input-field">
                <label for="documento-maestro">Documento maestro</label>
                <input type="text" id="documento-maestro" name="documento" inputmode="numeric"
                       pattern="[0-9]+" maxlength="20" autocomplete="username"
                       placeholder="Número de documento" required>
            </div>
            <div class="input-field">
                <label for="password-maestro">Contraseña</label>
                <input type="password" id="password-maestro" name="password"
                       autocomplete="current-password" placeholder="Contraseña" required>
            </div>
            <button class="btn-action" type="submit" style="width:100%;">Entrar al panel maestro</button>
        </form>
        <div class="auth-divider"><span>Acceso restringido</span></div>
        <a class="btn-secondary" href="index.php?vista=login">Volver al inicio de sesión</a>
    </div>
</section>
