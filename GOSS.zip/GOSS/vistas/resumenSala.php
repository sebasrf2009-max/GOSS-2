<?php
// Muestra lo que contiene una sala. Espera $sala, $inventarioSalas y $tiposElemento.
$salaId = (int) $sala["SalonId"];
?>
<?php if ($sala["FechaActualizacion"] === null): ?>
    <p class="form-help">Esta sala todavía no tiene su inventario registrado.</p>
<?php else: ?>
    <?php $totalDanados = 0; ?>
    <ul class="sala-lista">
        <?php foreach ($tiposElemento as $tipo): ?>
            <?php
            $item = $inventarioSalas[$salaId][(int) $tipo["TipoElementoId"]] ?? ["cantidad" => 0, "danados" => 0];
            $totalDanados += $item["danados"];
            ?>
            <li>
                <span><?= htmlspecialchars($tipo["Nombre"]) ?></span>
                <strong><?= $item["cantidad"] ?></strong>
                <?php if ($item["danados"] > 0): ?>
                    <small class="dato-danado"><?= $item["danados"] ?> dañado<?= $item["danados"] === 1 ? "" : "s" ?></small>
                <?php endif; ?>
            </li>
        <?php endforeach; ?>
    </ul>

    <p class="sala-estados">
        <span class="etiqueta <?= (int) $sala["Limpia"] === 1 ? "etiqueta-si" : "etiqueta-no" ?>">
            Limpia: <?= (int) $sala["Limpia"] === 1 ? "Sí" : "No" ?>
        </span>
        <span class="etiqueta <?= (int) $sala["Organizada"] === 1 ? "etiqueta-si" : "etiqueta-no" ?>">
            Organizada: <?= (int) $sala["Organizada"] === 1 ? "Sí" : "No" ?>
        </span>
        <span class="etiqueta <?= $totalDanados === 0 ? "etiqueta-si" : "etiqueta-no" ?>">
            <?= $totalDanados === 0 ? "Sin equipos dañados" : "Equipos dañados: " . $totalDanados ?>
        </span>
    </p>

    <?php if (!empty($sala["ObservacionesRegistro"])): ?>
        <p class="form-help">Observaciones: <?= htmlspecialchars($sala["ObservacionesRegistro"]) ?></p>
    <?php endif; ?>

    <p class="form-help">
        Actualizado el <?= htmlspecialchars($sala["FechaActualizacion"]) ?><?= !empty($sala["ActualizadoPor"]) ? " por " . htmlspecialchars($sala["ActualizadoPor"]) : "" ?>.
    </p>
<?php endif; ?>
