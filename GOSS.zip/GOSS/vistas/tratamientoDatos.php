<?php
// Casilla de autorización de tratamiento de datos personales (Ley 1581 de 2012).
// Al intentar marcarla se abre el cuadro con la explicación; la casilla solo
// queda marcada si la persona pulsa "Acepto" (ver abrirDatos() en goss.js).
?>
<div class="check-datos">
    <input type="checkbox" id="aceptaDatos" name="aceptaDatos" value="1" required
           onclick="if (this.checked) { this.checked = false; abrirDatos(); }">
    <label for="aceptaDatos">
        Autorizo el tratamiento de mis datos personales conforme a la Ley 1581 de 2012.
        <a href="#" onclick="abrirDatos(); return false;">Ver información</a>
    </label>
</div>

<dialog id="dialogo-datos" class="dialogo-datos" aria-labelledby="titulo-datos">
    <div class="dialogo-cabecera">
        <h3 id="titulo-datos">Tratamiento de datos personales</h3>
    </div>

    <div class="dialogo-cuerpo">
        <p>
            En Colombia la protección de los datos personales es un derecho fundamental,
            conocido como <strong>habeas data</strong>. Antes de usar GOSS, lea cómo se
            tratan sus datos y qué derechos tiene.
        </p>

        <h4>¿Qué dice la ley?</h4>
        <ul>
            <li>
                El <strong>artículo 15 de la Constitución Política</strong> reconoce que toda persona
                puede conocer, actualizar y rectificar la información que se haya recogido sobre ella
                en bases de datos y archivos públicos o privados.
            </li>
            <li>
                La <strong>Ley Estatutaria 1581 de 2012</strong> desarrolla ese derecho y fija las reglas
                generales para el tratamiento de datos personales. Fue reglamentada parcialmente por el
                Decreto 1377 de 2013 (hoy compilado en el Decreto 1074 de 2015) y por el Decreto 886 de 2014.
            </li>
            <li>
                La autoridad que vigila su cumplimiento es la <strong>Superintendencia de Industria y
                Comercio (SIC)</strong>.
            </li>
        </ul>

        <h4>Principios del tratamiento</h4>
        <ul>
            <li><strong>Legalidad:</strong> el tratamiento debe ajustarse a lo que dice la ley.</li>
            <li><strong>Finalidad:</strong> los datos se usan para un propósito legítimo que se le informa.</li>
            <li><strong>Libertad:</strong> solo se tratan con su autorización previa, expresa e informada.</li>
            <li><strong>Veracidad o calidad:</strong> la información debe ser veraz, completa y actualizada.</li>
            <li><strong>Transparencia:</strong> usted puede saber en cualquier momento qué datos suyos se tienen.</li>
            <li><strong>Acceso y circulación restringida:</strong> solo las personas autorizadas pueden consultarlos.</li>
            <li><strong>Seguridad:</strong> se aplican medidas para evitar pérdida, acceso o uso no autorizado.</li>
            <li><strong>Confidencialidad:</strong> quienes intervienen deben guardar reserva de la información.</li>
        </ul>

        <h4>Sus derechos como titular de los datos</h4>
        <ul>
            <li>Conocer, actualizar y rectificar sus datos personales.</li>
            <li>Pedir prueba de la autorización que usted dio.</li>
            <li>Ser informado, si lo solicita, del uso que se ha dado a sus datos.</li>
            <li>Presentar quejas ante la Superintendencia de Industria y Comercio por posibles infracciones.</li>
            <li>Revocar la autorización o pedir que se eliminen sus datos cuando no se respeten los principios,
                derechos y garantías de la ley.</li>
            <li>Acceder de forma gratuita a los datos que hayan sido tratados.</li>
        </ul>

        <h4>Qué datos recoge GOSS y para qué</h4>
        <ul>
            <li>
                <strong>Datos:</strong> nombre completo, número de documento, rol (docente, técnico o
                administrador), contraseña (se guarda cifrada), firma digital de los docentes, la fecha
                en que usted autoriza este tratamiento y los registros que usted genera: bitácoras
                (curso, sala, fecha y horas), fotografías de la sala y reportes de daños.
            </li>
            <li>
                <strong>Finalidad:</strong> identificar a los usuarios, llevar el control y la trazabilidad
                del uso y del estado de las salas de sistemas, gestionar los reportes de daños y generar las
                planillas de seguimiento de la institución.
            </li>
            <li>
                Sus datos se usan solo para estas finalidades y únicamente los consultan las personas
                autorizadas del sistema.
            </li>
        </ul>

        <h4>Cómo ejercer sus derechos</h4>
        <p>
            Puede pedir conocer, corregir o eliminar sus datos al administrador de GOSS en la institución.
            Si considera que no se atendieron sus derechos, puede presentar una queja ante la
            Superintendencia de Industria y Comercio (www.sic.gov.co).
        </p>

        <h4>Su autorización</h4>
        <p>
            Al pulsar «Acepto» usted autoriza de forma previa, expresa e informada el tratamiento de sus datos
            personales para las finalidades descritas. Puede revocar esta autorización cuando lo desee, salvo
            que exista un deber legal o contractual de conservar los datos.
        </p>

        <p class="dialogo-nota">
            Esta información es un resumen general de la normativa. La Ley 1581 de 2012 puede ser reformada
            (hay proyectos en trámite en el Congreso); para consultar el texto vigente visite www.sic.gov.co.
        </p>
    </div>

    <div class="dialogo-pie register-actions">
        <button type="button" class="btn-action" onclick="aceptarDatos()">Acepto el tratamiento de datos</button>
        <button type="button" class="btn-secondary" onclick="cerrarDatos()">Cerrar</button>
    </div>
</dialog>
