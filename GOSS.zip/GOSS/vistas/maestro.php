<?php
if (empty($_SESSION["csrf_maestro"])) {
    $_SESSION["csrf_maestro"] = bin2hex(random_bytes(32));
}
$etiquetasRol = ["Profesor" => "Docente", "Tecnico" => "Técnico", "Administrador" => "Administrador"];
?>
<section class="section active">
    <h2 class="screen-title">Administrador maestro</h2>
    <p class="screen-subtitle">Gestión privada de cuentas y permisos</p>
    <div class="form-container">
        <h3 class="form-titulo"><?= $usuarioEditar ? "Editar usuario" : "Crear usuario" ?></h3>
        <?php if ($usuarioEditar): ?>
            <p class="form-help">Deja la contraseña vacía para conservar la actual.</p>
        <?php else: ?>
            <p class="form-help">La cuenta se creará sin privilegios maestros. El usuario autorizará el tratamiento de datos al iniciar sesión.</p>
        <?php endif; ?>
        <form method="post" action="procesos/maestroUsuarios.php">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION["csrf_maestro"], ENT_QUOTES, "UTF-8") ?>">
            <input type="hidden" name="accion" value="guardar">
            <?php if ($usuarioEditar): ?>
                <input type="hidden" name="usuario_id" value="<?= (int) $usuarioEditar["UsuarioId"] ?>">
            <?php endif; ?>
            <div class="grid-form">
                <div class="input-field">
                    <label for="maestro-nombre">Nombre completo</label>
                    <input type="text" id="maestro-nombre" name="nombreCompleto" maxlength="100"
                           value="<?= htmlspecialchars($usuarioEditar["NombreCompleto"] ?? "", ENT_QUOTES, "UTF-8") ?>"
                           autocomplete="name" required>
                </div>
                <div class="input-field">
                    <label for="maestro-documento">Documento</label>
                    <input type="text" id="maestro-documento" name="documento" inputmode="numeric"
                           pattern="[0-9]{6,10}" minlength="6" maxlength="10"
                           value="<?= htmlspecialchars($usuarioEditar["Documento"] ?? "", ENT_QUOTES, "UTF-8") ?>"
                           required>
                </div>
                <div class="input-field">
                    <label for="maestro-rol">Rol</label>
                    <select id="maestro-rol" name="rol_id" required>
                        <option value="">Seleccione un rol</option>
                        <?php foreach ($roles as $rol): ?>
                            <option value="<?= (int) $rol["RolId"] ?>"
                                <?= $usuarioEditar && (int) $usuarioEditar["RolId"] === (int) $rol["RolId"] ? "selected" : "" ?>>
                                <?= htmlspecialchars($rol["NombreRol"] === "Tecnico" ? "Técnico" : $rol["NombreRol"]) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="input-field">
                    <label for="maestro-password">Contraseña<?= $usuarioEditar ? " (opcional)" : "" ?></label>
                    <input type="password" id="maestro-password" name="password"
                           minlength="8" maxlength="72" autocomplete="new-password"
                           <?= $usuarioEditar ? "" : "required" ?>>
                    <p class="form-help">Entre 8 y 72 caracteres, con al menos una letra y un número.</p>
                </div>
            </div>
            <div class="register-actions">
                <button class="btn-action" type="submit"><?= $usuarioEditar ? "Guardar cambios" : "Crear usuario" ?></button>
                <?php if ($usuarioEditar): ?>
                    <a class="btn-secondary" href="index.php?vista=maestro">Cancelar edición</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <div class="form-container">
        <h3 class="form-titulo">Control de usuarios</h3>
        <p class="form-help">Desde aquí puedes editar usuarios, restringir el acceso, reactivar cuentas o eliminar usuarios. Las cuentas maestras están protegidas.</p>
        <div class="table-wrapper">
            <table class="table-logs">
                <thead><tr><th>Usuario</th><th>Documento</th><th>Rol</th><th>Estado</th><th>Acciones</th></tr></thead>
                <tbody>
                <?php foreach ($usuarios as $u): ?>
                    <tr>
                        <td><?= htmlspecialchars($u["NombreCompleto"]) ?></td>
                        <td><?= htmlspecialchars($u["Documento"]) ?></td>
                        <td><?= htmlspecialchars($etiquetasRol[$u["NombreRol"]] ?? $u["NombreRol"]) ?></td>
                        <td><?= htmlspecialchars($u["EstadoCuenta"] ?? "ACTIVO") ?></td>
                        <td>
                        <?php if (!(int)($u["EsMaestro"] ?? 0) && (int)$u["UsuarioId"] !== $usuarioId): ?>
                            <div class="actions">
                                <a class="btn-mini" href="index.php?vista=maestro&amp;editar=<?= (int) $u["UsuarioId"] ?>">Editar</a>
                                <form method="post" action="procesos/maestroUsuarios.php">
                                    <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION["csrf_maestro"]) ?>">
                                    <input type="hidden" name="usuario_id" value="<?= (int)$u["UsuarioId"] ?>">
                                    <?php if (($u["EstadoCuenta"] ?? "ACTIVO") === "ACTIVO"): ?>
                                        <input type="hidden" name="accion" value="restringir">
                                        <button class="btn-danger btn-mini" type="submit" onclick="return confirm('¿Restringir el acceso de este usuario?')">Restringir</button>
                                    <?php else: ?>
                                        <input type="hidden" name="accion" value="activar">
                                        <button class="btn-mini" type="submit">Reactivar</button>
                                    <?php endif; ?>
                                </form>
                                <form method="post" action="procesos/maestroUsuarios.php">
                                    <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION["csrf_maestro"]) ?>">
                                    <input type="hidden" name="usuario_id" value="<?= (int)$u["UsuarioId"] ?>">
                                    <input type="hidden" name="accion" value="eliminar">
                                    <button class="btn-danger btn-mini" type="submit" onclick="return confirm('¿Eliminar definitivamente este usuario? Si tiene registros asociados, el sistema impedirá el borrado.')">Eliminar</button>
                                </form>
                            </div>
                        <?php else: ?><span class="badge resuelta">Protegido</span><?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if ($bitacoraEditar): ?>
        <div class="form-container">
            <h3 class="form-titulo">Editar bitácora N.º <?= (int) $bitacoraEditar["BitacoraId"] ?></h3>
            <p class="form-help">La foto de salida y la firma registradas se conservarán sin cambios.</p>
            <form method="post" action="procesos/maestroBitacoras.php">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION["csrf_maestro"], ENT_QUOTES, "UTF-8") ?>">
                <input type="hidden" name="accion" value="guardar">
                <input type="hidden" name="bitacora_id" value="<?= (int) $bitacoraEditar["BitacoraId"] ?>">
                <div class="grid-form">
                    <div class="input-field">
                        <label for="bitacora-fecha">Fecha</label>
                        <input type="date" id="bitacora-fecha" name="fecha"
                               value="<?= htmlspecialchars($bitacoraEditar["Fecha"], ENT_QUOTES, "UTF-8") ?>" required>
                    </div>
                    <div class="input-field">
                        <label for="bitacora-curso">Curso</label>
                        <input type="text" id="bitacora-curso" name="curso" maxlength="100" minlength="2"
                               value="<?= htmlspecialchars($bitacoraEditar["Curso"] ?? "", ENT_QUOTES, "UTF-8") ?>" required>
                    </div>
                    <div class="input-field">
                        <label for="bitacora-jornada">Nivel educativo</label>
                        <select id="bitacora-jornada" name="jornada" required>
                            <?php foreach (jornadasPermitidas() as $jornada): ?>
                                <option value="<?= htmlspecialchars($jornada, ENT_QUOTES, "UTF-8") ?>"
                                    <?= $jornada === $bitacoraEditar["Jornada"] ? "selected" : "" ?>>
                                    <?= htmlspecialchars($jornada) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="input-field">
                        <label for="bitacora-salon">Salón</label>
                        <select id="bitacora-salon" name="salon_id" required>
                            <?php foreach ($salasMaestro as $sala): ?>
                                <option value="<?= (int) $sala["SalonId"] ?>"
                                    <?= (int) $sala["SalonId"] === (int) $bitacoraEditar["SalonId"] ? "selected" : "" ?>>
                                    <?= htmlspecialchars($sala["Nombre"]) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="input-field">
                        <label for="bitacora-profesor">Docente</label>
                        <select id="bitacora-profesor" name="profesor_id" required>
                            <?php foreach ($profesores as $profesor): ?>
                                <option value="<?= (int) $profesor["UsuarioId"] ?>"
                                    <?= (int) $profesor["UsuarioId"] === (int) $bitacoraEditar["UsuarioProfesorId"] ? "selected" : "" ?>>
                                    <?= htmlspecialchars($profesor["NombreCompleto"]) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="input-field">
                        <label for="bitacora-responsable">Responsable</label>
                        <select id="bitacora-responsable" name="responsable_id" required>
                            <?php foreach ($responsables as $responsable): ?>
                                <option value="<?= (int) $responsable["UsuarioId"] ?>"
                                    <?= (int) $responsable["UsuarioId"] === (int) $bitacoraEditar["UsuarioResponsableId"] ? "selected" : "" ?>>
                                    <?= htmlspecialchars($responsable["NombreCompleto"]) ?>
                                    (<?= htmlspecialchars($responsable["NombreRol"] === "Tecnico" ? "Técnico" : $responsable["NombreRol"]) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="input-field">
                        <label for="bitacora-hora-entrada">Hora de entrada</label>
                        <input type="time" id="bitacora-hora-entrada" name="hora_entrada"
                               value="<?= htmlspecialchars(substr($bitacoraEditar["HoraEntrada"], 0, 5), ENT_QUOTES, "UTF-8") ?>" required>
                    </div>
                    <div class="input-field">
                        <label for="bitacora-hora-salida">Hora de salida</label>
                        <input type="time" id="bitacora-hora-salida" name="hora_salida"
                               value="<?= htmlspecialchars($bitacoraEditar["HoraSalida"] ? substr($bitacoraEditar["HoraSalida"], 0, 5) : "", ENT_QUOTES, "UTF-8") ?>">
                    </div>
                    <div class="input-field">
                        <label for="bitacora-limpia-entrada">Limpia al entrar</label>
                        <select id="bitacora-limpia-entrada" name="limpia_entrada" required>
                            <option value="1" <?= (int) $bitacoraEditar["LimpiaEntrada"] === 1 ? "selected" : "" ?>>Sí</option>
                            <option value="0" <?= (int) $bitacoraEditar["LimpiaEntrada"] === 0 ? "selected" : "" ?>>No</option>
                        </select>
                    </div>
                    <div class="input-field">
                        <label for="bitacora-limpia-salida">Limpia al salir</label>
                        <select id="bitacora-limpia-salida" name="limpia_salida">
                            <option value="" <?= $bitacoraEditar["LimpiaSalida"] === null ? "selected" : "" ?>>Sin registrar</option>
                            <option value="1" <?= (string) $bitacoraEditar["LimpiaSalida"] === "1" ? "selected" : "" ?>>Sí</option>
                            <option value="0" <?= (string) $bitacoraEditar["LimpiaSalida"] === "0" ? "selected" : "" ?>>No</option>
                        </select>
                    </div>
                    <div class="input-field">
                        <label for="bitacora-orden-salida">Orden al salir</label>
                        <select id="bitacora-orden-salida" name="orden_salida">
                            <option value="" <?= $bitacoraEditar["OrdenSalida"] === null ? "selected" : "" ?>>Sin registrar</option>
                            <option value="1" <?= (string) $bitacoraEditar["OrdenSalida"] === "1" ? "selected" : "" ?>>Sí</option>
                            <option value="0" <?= (string) $bitacoraEditar["OrdenSalida"] === "0" ? "selected" : "" ?>>No</option>
                        </select>
                    </div>
                </div>
                <div class="input-field">
                    <label for="bitacora-observaciones">Observaciones de salida</label>
                    <textarea id="bitacora-observaciones" name="observaciones" rows="4" maxlength="1000"><?= htmlspecialchars($bitacoraEditar["Observaciones"] ?? "", ENT_QUOTES, "UTF-8") ?></textarea>
                </div>
                <?php if ($bitacoraEditar["FotoSalida"]): ?>
                    <p class="form-help">Foto de salida actual:
                        <a href="<?= htmlspecialchars($bitacoraEditar["FotoSalida"], ENT_QUOTES, "UTF-8") ?>" target="_blank" rel="noopener">ver foto</a>
                    </p>
                <?php endif; ?>
                <div class="register-actions">
                    <button class="btn-action" type="submit">Guardar cambios de bitácora</button>
                    <a class="btn-secondary" href="index.php?vista=maestro">Cancelar edición</a>
                </div>
            </form>
        </div>
    <?php endif; ?>

    <div class="form-container">
        <h3 class="form-titulo">Registro de bitácoras</h3>
        <p class="form-help">Historial completo de aperturas y cierres. Al eliminar una bitácora también se eliminan sus novedades asociadas.</p>
        <div class="table-wrapper">
            <table class="table-logs">
                <thead>
                    <tr>
                        <th>N.º</th>
                        <th>Fecha</th>
                        <th>Horario</th>
                        <th>Salón</th>
                        <th>Curso</th>
                        <th>Docente</th>
                        <th>Responsable</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($bitacorasMaestro === false): ?>
                        <tr><td colspan="9">No fue posible cargar el historial.</td></tr>
                    <?php elseif (count($bitacorasMaestro) === 0): ?>
                        <tr><td colspan="9">Todavía no hay bitácoras registradas.</td></tr>
                    <?php else: ?>
                        <?php foreach ($bitacorasMaestro as $bitacora): ?>
                            <tr>
                                <td><?= (int) $bitacora["BitacoraId"] ?></td>
                                <td><?= htmlspecialchars($bitacora["Fecha"]) ?></td>
                                <td>
                                    <?= htmlspecialchars(substr($bitacora["HoraEntrada"], 0, 5)) ?>
                                    - <?= $bitacora["HoraSalida"] ? htmlspecialchars(substr($bitacora["HoraSalida"], 0, 5)) : "abierta" ?>
                                </td>
                                <td><?= htmlspecialchars($bitacora["Salon"]) ?></td>
                                <td><?= htmlspecialchars($bitacora["Curso"]) ?></td>
                                <td><?= htmlspecialchars($bitacora["Profesor"]) ?></td>
                                <td><?= htmlspecialchars($bitacora["Responsable"]) ?></td>
                                <td><?= htmlspecialchars(ucfirst(strtolower($bitacora["EstadoRegistro"]))) ?></td>
                                <td>
                                    <div class="actions">
                                        <a class="btn-mini" href="index.php?vista=maestro&amp;editar_bitacora=<?= (int) $bitacora["BitacoraId"] ?>">Editar</a>
                                        <form method="post" action="procesos/maestroBitacoras.php">
                                            <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION["csrf_maestro"], ENT_QUOTES, "UTF-8") ?>">
                                            <input type="hidden" name="accion" value="eliminar">
                                            <input type="hidden" name="bitacora_id" value="<?= (int) $bitacora["BitacoraId"] ?>">
                                            <button class="btn-danger btn-mini" type="submit"
                                                    onclick="return confirm('¿Eliminar esta bitácora y todas sus novedades asociadas? Esta acción no se puede deshacer.')">
                                                Eliminar
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
