<?php

// Guarda una imagen ya validada dentro de uploads/<carpeta>/ con un nombre
// aleatorio (nunca se usa el nombre que trae el archivo) y devuelve la ruta
// relativa que se guarda en la base de datos, o false si no se pudo guardar.
function guardarImagenSubida($archivo, $carpeta, $prefijo)
{
    $extension = extensionesImagen()[mime_content_type($archivo["tmp_name"])];
    $nombre = $prefijo . "_" . bin2hex(random_bytes(6)) . "." . $extension;
    $directorio = __DIR__ . "/../uploads/" . $carpeta . "/";

    if (!is_dir($directorio) && !mkdir($directorio, 0755, true)) {
        return false;
    }

    if (!move_uploaded_file($archivo["tmp_name"], $directorio . $nombre)) {
        return false;
    }

    return "uploads/" . $carpeta . "/" . $nombre;
}


function borrarImagenGuardada($ruta)
{
    $archivo = __DIR__ . "/../" . $ruta;

    if ($ruta !== null && is_file($archivo)) {
        unlink($archivo);
    }
}
