<?php

/* ------------------------------------------------------------------
 * Valores permitidos. Coinciden con los ENUM de la base de datos, así
 * que las vistas y las validaciones usan siempre esta misma lista.
 * ------------------------------------------------------------------ */

function jornadasPermitidas()
{
    return [
        "Educación preescolar",
        "Educación básica primaria",
        "Educación básica secundaria",
        "Educación media"
    ];
}

// valor guardado en la base => texto que ve el usuario
function nivelesDano()
{
    return [
        "Leve/Superficial" => "Leve / superficial",
        "Moderado/Medio"   => "Moderado / medio",
        "Grave/Severo"     => "Grave / severo",
        "Crítico/Urgente"  => "Crítico / urgente"
    ];
}

function estadosNovedad()
{
    return ["Pendiente", "En revisión", "Solucionado"];
}

function extensionesImagen()
{
    return [
        "image/png"  => "png",
        "image/jpeg" => "jpg",
        "image/webp" => "webp"
    ];
}


// Lee un campo de texto del formulario. Si no llegó, o llegó como arreglo,
// devuelve una cadena vacía para que las validaciones no fallen con errores.
function textoPost($campo, $recortar = true)
{
    if (!isset($_POST[$campo]) || !is_string($_POST[$campo])) {
        return "";
    }

    return $recortar ? trim($_POST[$campo]) : $_POST[$campo];
}


/* ------------------------------------------------------------------
 * Reglas de formato (se usan en varios formularios)
 * ------------------------------------------------------------------ */

// "  Ana   María " -> "Ana María"
function normalizarEspacios($texto)
{
    return trim(preg_replace('/\s+/u', ' ', $texto));
}


// Cédula o documento: solo números, entre 6 y 10 dígitos.
function documentoValido($documento)
{
    return preg_match('/^[0-9]{6,10}$/', $documento) === 1;
}


// Nombre y apellido: solo letras (con tildes, ñ), espacios, apóstrofo y guion.
function nombreValido($nombre)
{
    return mb_strlen($nombre) >= 5
        && mb_strlen($nombre) <= 100
        && preg_match('/^\p{L}[\p{L}\'’\-]*( [\p{L}\'’\-]+)+$/u', $nombre) === 1;
}


// Contraseña: de 8 a 72 caracteres (bcrypt solo lee los primeros 72),
// con al menos una letra y un número.
function passwordValida($password)
{
    return strlen($password) >= 8
        && strlen($password) <= 72
        && preg_match('/\p{L}/u', $password) === 1
        && preg_match('/[0-9]/', $password) === 1;
}


// Curso: letras, números, espacios y signos comunes ("1101 - Programación").
function cursoValido($curso)
{
    return preg_match('/^[\p{L}\p{N} .,\-()\/°º]{2,100}$/u', $curso) === 1;
}


function fechaBitacoraValida($fecha)
{
    if (!preg_match('/^([0-9]{4})-([0-9]{2})-([0-9]{2})$/', $fecha, $partes)) {
        return false;
    }

    return checkdate((int) $partes[2], (int) $partes[3], (int) $partes[1]);
}


function horaBitacoraValida($hora)
{
    if (!preg_match('/^([0-9]{2}):([0-9]{2})$/', $hora, $partes)) {
        return false;
    }

    return (int) $partes[1] <= 23 && (int) $partes[2] <= 59;
}


// Código de equipo: letras, números, guion y guion bajo ("PC-14").
function codigoEquipoValido($codigo)
{
    return preg_match('/^[A-Za-z0-9_\-]{1,50}$/', $codigo) === 1;
}


// La casilla de tratamiento de datos (Ley 1581 de 2012) tiene que venir marcada.
function autorizoTratamientoDatos()
{
    return textoPost("aceptaDatos") === "1";
}


/* ------------------------------------------------------------------
 * Acceso y usuarios
 * ------------------------------------------------------------------ */

function validarLogin()
{
    $documento = textoPost("documento");

    if ($documento === "" || textoPost("password", false) === "") {
        return "Ingrese el documento y la contraseña.";
    }

    // Aquí solo se exige que sean números (hasta 20, como en la base de datos)
    // para no dejar por fuera a usuarios creados con otras longitudes.
    if (!ctype_digit($documento) || strlen($documento) > 20) {
        return "El documento solo puede contener números.";
    }

    if (!autorizoTratamientoDatos()) {
        return "Debe autorizar el tratamiento de datos personales para continuar.";
    }

    return "";
}


function validarRegistroUsuario()
{
    $campos = [
        "nombreCompleto",
        "documentoRegistro",
        "rolRegistro",
        "passwordRegistro",
        "confirmarPassword"
    ];

    foreach ($campos as $campo) {
        if (textoPost($campo, false) === "") {
            return "Complete todos los campos para crear el usuario.";
        }
    }

    if (!nombreValido(normalizarEspacios(textoPost("nombreCompleto")))) {
        return "Escriba su nombre y apellido usando solo letras, sin números ni símbolos.";
    }

    if (!documentoValido(textoPost("documentoRegistro"))) {
        return "El documento debe tener solo números, entre 6 y 10 dígitos.";
    }

    if (filter_var(textoPost("rolRegistro"), FILTER_VALIDATE_INT) === false) {
        return "Seleccione un rol válido.";
    }

    if (!passwordValida(textoPost("passwordRegistro", false))) {
        return "La contraseña debe tener entre 8 y 72 caracteres, con al menos una letra y un número.";
    }

    if (textoPost("passwordRegistro", false) !== textoPost("confirmarPassword", false)) {
        return "Las contraseñas no coinciden.";
    }

    if (!autorizoTratamientoDatos()) {
        return "Debe autorizar el tratamiento de datos personales para crear el usuario.";
    }

    return "";
}


/* ------------------------------------------------------------------
 * Bitácora
 * ------------------------------------------------------------------ */

// Apertura de la bitácora (entrada a la sala).
function validarBitacora()
{
    $campos = ["curso", "jornada", "salon", "participante", "limpiezaEntrada"];

    foreach ($campos as $campo) {
        if (textoPost($campo) === "") {
            return "Complete los datos de la bitácora.";
        }
    }

    if (!cursoValido(normalizarEspacios(textoPost("curso")))) {
        return "El curso solo puede tener letras, números y los signos . , - ( ) / (máximo 100 caracteres).";
    }

    if (!in_array(textoPost("jornada"), jornadasPermitidas(), true)) {
        return "Seleccione un nivel educativo válido.";
    }

    if (filter_var(textoPost("salon"), FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]]) === false) {
        return "Seleccione un salón válido.";
    }

    if (filter_var(textoPost("participante"), FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]]) === false) {
        return "Seleccione a la persona que acompaña el registro.";
    }

    if (!in_array(textoPost("limpiezaEntrada"), ["0", "1"], true)) {
        return "El valor de limpieza no es válido.";
    }

    return "";
}


// Cierre de la bitácora (salida de la sala y firma del docente).
function validarCierreBitacora()
{
    if (filter_var(textoPost("bitacoraId"), FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]]) === false) {
        return "Seleccione la bitácora que desea cerrar.";
    }

    if (!in_array(textoPost("limpiezaSalida"), ["0", "1"], true)) {
        return "El valor de limpieza no es válido.";
    }

    if (!in_array(textoPost("ordenSalida"), ["0", "1"], true)) {
        return "El valor de orden no es válido.";
    }

    if (mb_strlen(textoPost("observaciones")) > 1000) {
        return "Las observaciones no pueden superar los 1000 caracteres.";
    }

    return "";
}


// Revisa una imagen subida: que exista (si es obligatoria), que no pase del
// tamaño máximo y que de verdad sea PNG, JPG o WEBP (se mira el contenido,
// no solo la extensión).
function validarImagen($archivo, $obligatoria, $maxMegas, $queSubir)
{
    $hayArchivo = is_array($archivo) && $archivo["error"] !== UPLOAD_ERR_NO_FILE;

    if (!$hayArchivo) {
        return $obligatoria ? "Debe subir " . $queSubir . "." : "";
    }

    // PHP corta el archivo por su cuenta si supera el límite del servidor.
    if ($archivo["error"] === UPLOAD_ERR_INI_SIZE || $archivo["error"] === UPLOAD_ERR_FORM_SIZE) {
        return "La imagen no puede superar los " . $maxMegas . " MB.";
    }

    if ($archivo["error"] !== UPLOAD_ERR_OK) {
        return "No fue posible cargar la imagen. Intente de nuevo.";
    }

    if ($archivo["size"] > $maxMegas * 1024 * 1024) {
        return "La imagen no puede superar los " . $maxMegas . " MB.";
    }

    if (!array_key_exists(mime_content_type($archivo["tmp_name"]), extensionesImagen())) {
        return "La imagen debe ser PNG, JPG o WEBP.";
    }

    return "";
}


// La firma es obligatoria solo si el docente todavía no tiene una registrada.
function validarFirma($archivo, $obligatoria)
{
    return validarImagen($archivo, $obligatoria, 2, "la imagen de la firma del docente");
}


// La foto de cómo queda la sala siempre es obligatoria al cerrar.
function validarFotoSala($archivo)
{
    return validarImagen($archivo, true, 8, "la foto de cómo queda la sala");
}


// La hora de salida tiene que ser posterior a la de entrada (lo exige la
// base de datos). Si la bitácora se quedó abierta de un día anterior se
// cierra al final de ese día. Devuelve null si no hay una hora válida.
function calcularHoraSalida($fechaBitacora, $horaEntrada)
{
    $horaSalida = $fechaBitacora === date("Y-m-d") ? date("H:i:s") : "23:59:59";

    return $horaSalida > $horaEntrada ? $horaSalida : null;
}


// Registro de una sala: por cada tipo de elemento ($idsTipos viene de la tabla
// tipo_elemento) la cantidad que hay y cuántos están dañados, además de si la
// sala está limpia, organizada y unas observaciones opcionales.
function validarRegistroSala($idsTipos)
{
    if (filter_var(textoPost("salonId"), FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]]) === false) {
        return "Seleccione una sala válida.";
    }

    foreach ($idsTipos as $tipoId) {
        $cantidad = valorNumericoPost("cantidad", $tipoId);
        $danados = valorNumericoPost("danados", $tipoId);

        if ($cantidad === null) {
            return "Ingrese una cantidad válida (entre 0 y 999) para cada elemento.";
        }

        if ($danados === null) {
            return "Ingrese cuántos equipos dañados hay de cada tipo (0 si ninguno).";
        }

        if ($danados > $cantidad) {
            return "Los equipos dañados no pueden ser más que los que hay en la sala.";
        }
    }

    if (!in_array(textoPost("limpia"), ["0", "1"], true)) {
        return "Indique si la sala está limpia.";
    }

    if (!in_array(textoPost("organizada"), ["0", "1"], true)) {
        return "Indique si la sala está organizada.";
    }

    if (mb_strlen(textoPost("observacionesSala")) > 1000) {
        return "Las observaciones no pueden superar los 1000 caracteres.";
    }

    return "";
}


// Lee $_POST[$grupo][$tipoId] como número entre 0 y 999. Devuelve null si
// falta, no es un número entero o se pasa del rango.
function valorNumericoPost($grupo, $tipoId)
{
    $valores = $_POST[$grupo] ?? null;

    if (!is_array($valores) || !isset($valores[$tipoId]) || !is_string($valores[$tipoId])) {
        return null;
    }

    $valor = trim($valores[$tipoId]);

    if ($valor === "" || !ctype_digit($valor) || (int) $valor > 999) {
        return null;
    }

    return (int) $valor;
}


// Devuelve [TipoElementoId => número] del grupo indicado ("cantidad" o
// "danados"). Se usa después de validarRegistroSala().
function leerValores($grupo, $idsTipos)
{
    $valores = [];

    foreach ($idsTipos as $tipoId) {
        $valores[$tipoId] = valorNumericoPost($grupo, $tipoId);
    }

    return $valores;
}


/* ------------------------------------------------------------------
 * Novedades
 * ------------------------------------------------------------------ */

function validarNovedad()
{
    if (filter_var(textoPost("bitacoraId"), FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]]) === false) {
        return "Seleccione la bitácora del reporte.";
    }

    if (textoPost("equipo") === "") {
        return "Ingrese el número o código del equipo.";
    }

    if (!codigoEquipoValido(textoPost("equipo"))) {
        return "El equipo solo puede tener letras, números y guiones (por ejemplo 14 o PC-14).";
    }

    if (mb_strlen(textoPost("descripcion")) < 5) {
        return "Describa la falla encontrada (mínimo 5 caracteres).";
    }

    if (mb_strlen(textoPost("descripcion")) > 1000) {
        return "La descripción no puede superar los 1000 caracteres.";
    }

    if (!array_key_exists(textoPost("nivelDano"), nivelesDano())) {
        return "Seleccione un nivel de daño válido.";
    }

    return "";
}


// "14" se convierte en "PC-14" para no duplicar equipos ya inventariados.
function normalizarCodigoEquipo($entrada)
{
    $codigo = mb_strtoupper(trim($entrada));

    if (ctype_digit($codigo)) {
        return "PC-" . str_pad($codigo, 2, "0", STR_PAD_LEFT);
    }

    return $codigo;
}


function nombreEquipoDesdeCodigo($codigo)
{
    if (preg_match('/^PC-(\d+)$/', $codigo, $coincidencia)) {
        return "Computador " . $coincidencia[1];
    }

    return $codigo;
}
