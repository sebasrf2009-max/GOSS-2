-- Ejecutar UNA SOLA VEZ sobre la base de datos GOSS ya existente.
ALTER TABLE usuario
    ADD COLUMN EsMaestro TINYINT(1) NOT NULL DEFAULT 0,
    ADD COLUMN EstadoCuenta ENUM('ACTIVO','RESTRINGIDO') NOT NULL DEFAULT 'ACTIVO';

-- Después de registrar tu cuenta normal, reemplaza DOCUMENTO_PROPIO por tu documento:
-- UPDATE usuario SET EsMaestro = 1 WHERE Documento = 'DOCUMENTO_PROPIO';
-- Verifica que solo tu cuenta tenga EsMaestro = 1.

-- Crea o actualiza la cuenta maestra solicitada.
-- La contraseña se almacena con hash bcrypt; no queda en texto plano.
INSERT INTO usuario (NombreCompleto, Documento, Correo, RolId, Password, EsMaestro, EstadoCuenta)
SELECT 'Administrador Maestro', '1026567673', NULL, RolId,
       '$2y$12$qmks/1du177LRcZoETNBbeJ15Oar5r9RVX9/Pl8OMBjr73/qHmPnG', 1, 'ACTIVO'
FROM roles
WHERE NombreRol = 'Administrador'
ON DUPLICATE KEY UPDATE
    NombreCompleto = VALUES(NombreCompleto),
    RolId = VALUES(RolId),
    Password = VALUES(Password),
    EsMaestro = 1,
    EstadoCuenta = 'ACTIVO';
