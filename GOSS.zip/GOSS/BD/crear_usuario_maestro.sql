-- Ejecutar después de importar BD/goss.sql en una instalación nueva.
INSERT INTO usuario (NombreCompleto, Documento, Correo, RolId, Password, EsMaestro, EstadoCuenta)
SELECT 'Administrador Maestro', '1026567673', NULL, RolId,
       '$2y$12$qmks/1du177LRcZoETNBbeJ15Oar5r9RVX9/Pl8OMBjr73/qHmPnG', 1, 'ACTIVO'
FROM roles
WHERE NombreRol = 'Administrador'
ON DUPLICATE KEY UPDATE
    NombreCompleto = VALUES(NombreCompleto),
    RolId = VALUES(RolId),
    Password = VALUES(Password),
    EsMaestro = 1,
    EstadoCuenta = 'ACTIVO';
