DROP DATABASE IF EXISTS goss;
CREATE DATABASE goss
    DEFAULT CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
USE goss;


CREATE TABLE roles (
    RolId TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    NombreRol VARCHAR(20) NOT NULL UNIQUE,
    NivelJerarquia TINYINT UNSIGNED NOT NULL UNIQUE
) ENGINE=InnoDB;

INSERT INTO roles (NombreRol, NivelJerarquia)
VALUES
('Profesor', 1),
('Tecnico', 2),
('Administrador', 3);


CREATE TABLE usuario (
    UsuarioId INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    NombreCompleto VARCHAR(100) NOT NULL,
    Documento VARCHAR(20) NOT NULL UNIQUE,
    Correo VARCHAR(100) NULL UNIQUE,
    RolId TINYINT UNSIGNED NOT NULL,
    Password VARCHAR(255) NOT NULL,
    FirmaDigital VARCHAR(255) NULL,

    -- Fecha en que la persona autorizó el tratamiento de sus datos personales
    -- (Ley 1581 de 2012). Sirve como prueba de la autorización.
    FechaAutorizacionDatos DATETIME NULL,
    EsMaestro TINYINT(1) NOT NULL DEFAULT 0,
    EstadoCuenta ENUM('ACTIVO','RESTRINGIDO') NOT NULL DEFAULT 'ACTIVO',

    CONSTRAINT fk_usuario_rol
        FOREIGN KEY (RolId)
        REFERENCES roles(RolId)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB;


CREATE TABLE curso (
    CursoId INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;


CREATE TABLE salon (
    SalonId INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL UNIQUE,
    Estado ENUM(
        'DISPONIBLE',
        'MANTENIMIENTO',
        'FUERA_DE_SERVICIO'
    ) NOT NULL DEFAULT 'DISPONIBLE',

    -- Registro de la sala: estado general e inventario (ver salon_inventario).
    -- Se edita de vez en cuando, no a diario. Mientras FechaActualizacion sea
    -- NULL la sala todavía no tiene registro.
    Limpia TINYINT(1) NULL,
    Organizada TINYINT(1) NULL,
    ObservacionesRegistro TEXT NULL,
    FechaActualizacion DATETIME NULL,
    UsuarioActualizacionId INT UNSIGNED NULL,

    CONSTRAINT fk_salon_usuario_actualizacion
        FOREIGN KEY (UsuarioActualizacionId)
        REFERENCES usuario(UsuarioId)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB;


CREATE TABLE equipo (
    EquipoId INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    CodigoInventario VARCHAR(50) NOT NULL,
    NombreEquipo VARCHAR(100) NOT NULL,
    Estado ENUM(
        'OPERATIVO',
        'DAÑADO',
        'MANTENIMIENTO',
        'BAJA'
    ) NOT NULL DEFAULT 'OPERATIVO',
    SalonId INT UNSIGNED NOT NULL,

    CONSTRAINT fk_equipo_salon
        FOREIGN KEY (SalonId)
        REFERENCES salon(SalonId)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    UNIQUE KEY uq_equipo_salon_codigo (SalonId, CodigoInventario)
) ENGINE=InnoDB;


CREATE TABLE bitacora (
    BitacoraId INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    UsuarioProfesorId INT UNSIGNED NOT NULL,
    UsuarioResponsableId INT UNSIGNED NOT NULL,

    SalonId INT UNSIGNED NOT NULL,
    CursoId INT UNSIGNED NOT NULL,

    Jornada ENUM(
        'Educación preescolar',
        'Educación básica primaria',
        'Educación básica secundaria',
        'Educación media'
    ) NOT NULL,

    Fecha DATE NOT NULL,
    HoraEntrada TIME NOT NULL,
    HoraSalida TIME NULL,

    LimpiaEntrada TINYINT(1) NOT NULL DEFAULT 0,
    LimpiaSalida TINYINT(1) NULL,
    OrdenSalida TINYINT(1) NULL,

    Observaciones TEXT NULL,

    -- Foto de cómo se deja la sala al salir.
    FotoSalida VARCHAR(255) NULL,

    FechaFirma DATETIME NULL,

    EstadoRegistro ENUM(
        'ABIERTA',
        'FINALIZADA',
        'ANULADA'
    ) NOT NULL DEFAULT 'ABIERTA',

    CONSTRAINT fk_bitacora_profesor
        FOREIGN KEY (UsuarioProfesorId)
        REFERENCES usuario(UsuarioId)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT fk_bitacora_responsable
        FOREIGN KEY (UsuarioResponsableId)
        REFERENCES usuario(UsuarioId)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT fk_bitacora_salon
        FOREIGN KEY (SalonId)
        REFERENCES salon(SalonId)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT fk_bitacora_curso
        FOREIGN KEY (CursoId)
        REFERENCES curso(CursoId)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT chk_horas_validas
        CHECK (
            HoraSalida IS NULL OR HoraSalida > HoraEntrada
        ),

    CONSTRAINT chk_cierre_bitacora
        CHECK (
            EstadoRegistro <> 'FINALIZADA'
            OR (
                HoraSalida IS NOT NULL
                AND LimpiaSalida IS NOT NULL
                AND OrdenSalida IS NOT NULL
                AND FechaFirma IS NOT NULL
            )
        ),

    INDEX idx_bitacora_fecha (Fecha),
    INDEX idx_bitacora_salon_fecha (SalonId, Fecha),
    INDEX idx_bitacora_profesor (UsuarioProfesorId)
) ENGINE=InnoDB;


CREATE TABLE bitacora_equipo (
    BitacoraId INT UNSIGNED NOT NULL,
    EquipoId INT UNSIGNED NOT NULL,

    NivelDano ENUM(
        'Leve/Superficial',
        'Moderado/Medio',
        'Grave/Severo',
        'Crítico/Urgente'
    ) NOT NULL,

    DescripcionFalla TEXT NOT NULL,

    EstadoNovedad ENUM(
        'Pendiente',
        'En revisión',
        'Solucionado'
    ) NOT NULL DEFAULT 'Pendiente',

    TecnicoId INT UNSIGNED NULL,
    FechaReporte DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (BitacoraId, EquipoId),

    CONSTRAINT fk_be_bitacora
        FOREIGN KEY (BitacoraId)
        REFERENCES bitacora(BitacoraId)
        ON UPDATE CASCADE
        ON DELETE CASCADE,

    CONSTRAINT fk_be_equipo
        FOREIGN KEY (EquipoId)
        REFERENCES equipo(EquipoId)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT fk_be_tecnico
        FOREIGN KEY (TecnicoId)
        REFERENCES usuario(UsuarioId)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    INDEX idx_be_equipo (EquipoId),
    INDEX idx_be_estado (EstadoNovedad),
    INDEX idx_be_tecnico (TecnicoId)
) ENGINE=InnoDB;


CREATE TABLE tipo_elemento (
    TipoElementoId TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB;


CREATE TABLE salon_inventario (
    SalonId INT UNSIGNED NOT NULL,
    TipoElementoId TINYINT UNSIGNED NOT NULL,
    Cantidad SMALLINT UNSIGNED NOT NULL,
    CantidadDanada SMALLINT UNSIGNED NOT NULL DEFAULT 0,

    PRIMARY KEY (SalonId, TipoElementoId),

    CONSTRAINT chk_danados_validos
        CHECK (CantidadDanada <= Cantidad),

    CONSTRAINT fk_si_salon
        FOREIGN KEY (SalonId)
        REFERENCES salon(SalonId)
        ON UPDATE CASCADE
        ON DELETE CASCADE,

    CONSTRAINT fk_si_tipo_elemento
        FOREIGN KEY (TipoElementoId)
        REFERENCES tipo_elemento(TipoElementoId)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    INDEX idx_si_tipo_elemento (TipoElementoId)
) ENGINE=InnoDB;


INSERT INTO tipo_elemento (Nombre) VALUES
('PCs'),
('Teclados'),
('Mouse'),
('Televisores'),
('Proyectores');

INSERT INTO curso (Nombre) VALUES
('1101 - Programación'),
('1102 - Técnica'),
('1001 - Introducción Software');

INSERT INTO salon (Nombre, Estado) VALUES
('Sala de Sistemas 1', 'DISPONIBLE'),
('Sala de Sistemas 2', 'DISPONIBLE'),
('Sala de Sistemas 3', 'DISPONIBLE'),
('Sala de Sistemas 4', 'DISPONIBLE');

INSERT INTO equipo (CodigoInventario, NombreEquipo, Estado, SalonId) VALUES
('PC-01', 'Computador 01', 'OPERATIVO', 1),
('PC-02', 'Computador 02', 'OPERATIVO', 1),
('PC-14', 'Computador 14', 'OPERATIVO', 1);


DELIMITER $$

CREATE TRIGGER trg_bitacora_roles_bi
BEFORE INSERT ON bitacora
FOR EACH ROW
BEGIN
    DECLARE rol_profesor VARCHAR(20);
    DECLARE rol_responsable VARCHAR(20);

    SELECT r.NombreRol
      INTO rol_profesor
      FROM usuario u
      INNER JOIN roles r ON r.RolId = u.RolId
     WHERE u.UsuarioId = NEW.UsuarioProfesorId;

    SELECT r.NombreRol
      INTO rol_responsable
      FROM usuario u
      INNER JOIN roles r ON r.RolId = u.RolId
     WHERE u.UsuarioId = NEW.UsuarioResponsableId;

    IF rol_profesor IS NULL OR rol_profesor <> 'Profesor' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'UsuarioProfesorId debe corresponder a un Profesor';
    END IF;

    IF rol_responsable IS NULL
       OR rol_responsable NOT IN ('Administrador', 'Tecnico') THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'UsuarioResponsableId debe corresponder a Administrador o Tecnico';
    END IF;
END$$

CREATE TRIGGER trg_bitacora_roles_bu
BEFORE UPDATE ON bitacora
FOR EACH ROW
BEGIN
    DECLARE rol_profesor VARCHAR(20);
    DECLARE rol_responsable VARCHAR(20);

    SELECT r.NombreRol
      INTO rol_profesor
      FROM usuario u
      INNER JOIN roles r ON r.RolId = u.RolId
     WHERE u.UsuarioId = NEW.UsuarioProfesorId;

    SELECT r.NombreRol
      INTO rol_responsable
      FROM usuario u
      INNER JOIN roles r ON r.RolId = u.RolId
     WHERE u.UsuarioId = NEW.UsuarioResponsableId;

    IF rol_profesor IS NULL OR rol_profesor <> 'Profesor' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'UsuarioProfesorId debe corresponder a un Profesor';
    END IF;

    IF rol_responsable IS NULL
       OR rol_responsable NOT IN ('Administrador', 'Tecnico') THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'UsuarioResponsableId debe corresponder a Administrador o Tecnico';
    END IF;
END$$

CREATE TRIGGER trg_bitacora_equipo_bi
BEFORE INSERT ON bitacora_equipo
FOR EACH ROW
BEGIN
    DECLARE salon_bitacora INT UNSIGNED;
    DECLARE salon_equipo INT UNSIGNED;
    DECLARE rol_tecnico VARCHAR(20);

    SELECT SalonId
      INTO salon_bitacora
      FROM bitacora
     WHERE BitacoraId = NEW.BitacoraId;

    SELECT SalonId
      INTO salon_equipo
      FROM equipo
     WHERE EquipoId = NEW.EquipoId;

    IF salon_bitacora IS NULL
       OR salon_equipo IS NULL
       OR salon_bitacora <> salon_equipo THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'El equipo debe pertenecer al mismo salon de la bitacora';
    END IF;

    IF NEW.TecnicoId IS NOT NULL THEN
        SELECT r.NombreRol
          INTO rol_tecnico
          FROM usuario u
          INNER JOIN roles r ON r.RolId = u.RolId
         WHERE u.UsuarioId = NEW.TecnicoId;

        IF rol_tecnico IS NULL OR rol_tecnico <> 'Tecnico' THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'TecnicoId debe corresponder a un usuario con rol Tecnico';
        END IF;
    END IF;
END$$

CREATE TRIGGER trg_bitacora_equipo_bu
BEFORE UPDATE ON bitacora_equipo
FOR EACH ROW
BEGIN
    DECLARE salon_bitacora INT UNSIGNED;
    DECLARE salon_equipo INT UNSIGNED;
    DECLARE rol_tecnico VARCHAR(20);

    SELECT SalonId
      INTO salon_bitacora
      FROM bitacora
     WHERE BitacoraId = NEW.BitacoraId;

    SELECT SalonId
      INTO salon_equipo
      FROM equipo
     WHERE EquipoId = NEW.EquipoId;

    IF salon_bitacora IS NULL
       OR salon_equipo IS NULL
       OR salon_bitacora <> salon_equipo THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'El equipo debe pertenecer al mismo salon de la bitacora';
    END IF;

    IF NEW.TecnicoId IS NOT NULL THEN
        SELECT r.NombreRol
          INTO rol_tecnico
          FROM usuario u
          INNER JOIN roles r ON r.RolId = u.RolId
         WHERE u.UsuarioId = NEW.TecnicoId;

        IF rol_tecnico IS NULL OR rol_tecnico <> 'Tecnico' THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'TecnicoId debe corresponder a un usuario con rol Tecnico';
        END IF;
    END IF;
END$$

DELIMITER ;
