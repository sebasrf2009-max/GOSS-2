<?php

// Convierte un resultado de consulta en un arreglo de filas (vacío si falló).
function filasDe($resultado)
{
    return $resultado ? $resultado->fetch_all(MYSQLI_ASSOC) : [];
}


/* ------------------------------------------------------------------
 * USUARIOS Y ROLES
 * ------------------------------------------------------------------ */

function listarRoles($conexion)
{
    $sql = "SELECT RolId, NombreRol
            FROM roles
            ORDER BY NivelJerarquia";

    return $conexion->query($sql);
}


function buscarUsuario($conexion, $documento)
{
    $sql = "SELECT u.UsuarioId, u.NombreCompleto, u.Documento,
                   r.NombreRol, u.Password
            FROM usuario u
            INNER JOIN roles r ON r.RolId = u.RolId
            WHERE u.Documento = ?";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("s", $documento);
    $stmt->execute();

    return $stmt->get_result()->fetch_assoc();
}


function buscarUsuarioPorId($conexion, $usuarioId)
{
    $sql = "SELECT u.UsuarioId, u.NombreCompleto, r.NombreRol
            FROM usuario u
            INNER JOIN roles r ON r.RolId = u.RolId
            WHERE u.UsuarioId = ?";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("i", $usuarioId);
    $stmt->execute();

    return $stmt->get_result()->fetch_assoc();
}


function existeUsuarioPorDocumento($conexion, $documento)
{
    $sql = "SELECT UsuarioId
            FROM usuario
            WHERE Documento = ?";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("s", $documento);
    $stmt->execute();

    return $stmt->get_result()->num_rows > 0;
}


function existeDocumentoUsuarioExcepto($conexion, $documento, $usuarioId)
{
    $sql = "SELECT UsuarioId
            FROM usuario
            WHERE Documento = ? AND UsuarioId <> ?";
    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("si", $documento, $usuarioId);
    $stmt->execute();

    return $stmt->get_result()->num_rows > 0;
}


function obtenerUsuarioEditable($conexion, $usuarioId)
{
    $sql = "SELECT UsuarioId, NombreCompleto, Documento, RolId, EsMaestro
            FROM usuario
            WHERE UsuarioId = ?";
    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("i", $usuarioId);
    $stmt->execute();

    return $stmt->get_result()->fetch_assoc();
}


function existeRol($conexion, $rolId)
{
    $stmt = $conexion->prepare("SELECT RolId FROM roles WHERE RolId = ?");

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("i", $rolId);
    $stmt->execute();

    return $stmt->get_result()->num_rows === 1;
}


function crearUsuarioDesdeMaestro($conexion, $nombreCompleto, $documento, $rolId, $password)
{
    $sql = "INSERT INTO usuario (NombreCompleto, Documento, RolId, Password)
            VALUES (?, ?, ?, ?)";
    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("ssis", $nombreCompleto, $documento, $rolId, $password);

    return $stmt->execute();
}


function actualizarUsuarioDesdeMaestro($conexion, $usuarioId, $nombreCompleto, $documento, $rolId, $password)
{
    if ($password === null) {
        $sql = "UPDATE usuario
                SET NombreCompleto = ?, Documento = ?, RolId = ?
                WHERE UsuarioId = ? AND EsMaestro = 0";
        $stmt = $conexion->prepare($sql);

        if (!$stmt) {
            return false;
        }

        $stmt->bind_param("ssii", $nombreCompleto, $documento, $rolId, $usuarioId);
    } else {
        $sql = "UPDATE usuario
                SET NombreCompleto = ?, Documento = ?, RolId = ?, Password = ?
                WHERE UsuarioId = ? AND EsMaestro = 0";
        $stmt = $conexion->prepare($sql);

        if (!$stmt) {
            return false;
        }

        $stmt->bind_param("ssisi", $nombreCompleto, $documento, $rolId, $password, $usuarioId);
    }

    return $stmt->execute() && $stmt->affected_rows >= 0;
}


function insertarUsuario($conexion, $nombreCompleto, $documento, $rolId, $password, $fechaAutorizacion)
{
    $sql = "INSERT INTO usuario
            (NombreCompleto, Documento, RolId, Password, FechaAutorizacionDatos)
            VALUES (?, ?, ?, ?, ?)";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("ssiss", $nombreCompleto, $documento, $rolId, $password, $fechaAutorizacion);

    return $stmt->execute();
}


// Guarda la fecha de la primera autorización de datos si la persona aún no
// tenía una (por ejemplo, usuarios creados antes de existir la casilla).
function registrarAutorizacionDatos($conexion, $usuarioId, $fecha)
{
    $sql = "UPDATE usuario
            SET FechaAutorizacionDatos = ?
            WHERE UsuarioId = ? AND FechaAutorizacionDatos IS NULL";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("si", $fecha, $usuarioId);

    return $stmt->execute();
}


// Todos los usuarios registrados, en orden de registro (para la lista del
// administrador). Nunca se trae la contraseña.
function listarUsuarios($conexion)
{
    $sql = "SELECT u.UsuarioId, u.NombreCompleto, u.Documento, r.NombreRol,
                   (u.FirmaDigital IS NOT NULL) AS TieneFirma,
                   u.FechaAutorizacionDatos, u.EsMaestro, u.EstadoCuenta
            FROM usuario u
            INNER JOIN roles r ON r.RolId = u.RolId
            ORDER BY u.UsuarioId";

    $resultado = $conexion->query($sql);
    if (!$resultado) {
        error_log("No fue posible consultar los usuarios: " . $conexion->error);
        return false;
    }

    return filasDe($resultado);
}


// Devuelve los usuarios que tengan alguno de los roles indicados.
// Se usa para elegir al docente o al responsable de la bitácora.
function listarUsuariosPorRol($conexion, $roles)
{
    $marcas = implode(",", array_fill(0, count($roles), "?"));

    $sql = "SELECT u.UsuarioId, u.NombreCompleto, r.NombreRol
            FROM usuario u
            INNER JOIN roles r ON r.RolId = u.RolId
            WHERE r.NombreRol IN ($marcas)
            ORDER BY u.NombreCompleto";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param(str_repeat("s", count($roles)), ...$roles);
    $stmt->execute();

    return $stmt->get_result();
}


function obtenerFirmaUsuario($conexion, $usuarioId)
{
    $sql = "SELECT FirmaDigital
            FROM usuario
            WHERE UsuarioId = ?";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return null;
    }

    $stmt->bind_param("i", $usuarioId);
    $stmt->execute();

    $fila = $stmt->get_result()->fetch_assoc();

    return $fila ? $fila["FirmaDigital"] : null;
}


function actualizarFirmaUsuario($conexion, $usuarioId, $ruta)
{
    $sql = "UPDATE usuario
            SET FirmaDigital = ?
            WHERE UsuarioId = ?";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("si", $ruta, $usuarioId);

    return $stmt->execute();
}


/* ------------------------------------------------------------------
 * CURSOS Y SALONES
 * ------------------------------------------------------------------ */

function listarCursos($conexion)
{
    $sql = "SELECT Nombre
            FROM curso
            ORDER BY Nombre";

    return $conexion->query($sql);
}


// El curso se escribe a mano. Si coincide con uno existente (por nombre
// completo o por su código, por ejemplo "1101") se reutiliza; si no, se crea.
function obtenerOCrearCurso($conexion, $nombre)
{
    $sql = "SELECT CursoId
            FROM curso
            WHERE Nombre = ? OR Nombre LIKE ?
            ORDER BY (Nombre = ?) DESC
            LIMIT 1";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $patron = addcslashes($nombre, "%_\\") . " - %";

    $stmt->bind_param("sss", $nombre, $patron, $nombre);
    $stmt->execute();

    $fila = $stmt->get_result()->fetch_assoc();

    if ($fila) {
        return (int) $fila["CursoId"];
    }

    $stmt = $conexion->prepare("INSERT INTO curso (Nombre) VALUES (?)");

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("s", $nombre);

    return $stmt->execute() ? $conexion->insert_id : false;
}


function salonDisponible($conexion, $salonId)
{
    $sql = "SELECT SalonId
            FROM salon
            WHERE SalonId = ? AND Estado = 'DISPONIBLE'";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("i", $salonId);
    $stmt->execute();

    return $stmt->get_result()->num_rows > 0;
}


/* ------------------------------------------------------------------
 * BITÁCORA
 * ------------------------------------------------------------------ */

// Apertura: se registra la entrada al salón. El cierre se hace después.
function insertarBitacora(
    $conexion,
    $profesorId,
    $responsableId,
    $salonId,
    $cursoId,
    $jornada,
    $fecha,
    $horaEntrada,
    $limpiaEntrada
) {
    $sql = "INSERT INTO bitacora
            (
                UsuarioProfesorId,
                UsuarioResponsableId,
                SalonId,
                CursoId,
                Jornada,
                Fecha,
                HoraEntrada,
                LimpiaEntrada,
                EstadoRegistro
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'ABIERTA')";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        error_log("Error preparar insertarBitacora: " . $conexion->error);
        return false;
    }

    $stmt->bind_param(
        "iiiisssi",
        $profesorId,
        $responsableId,
        $salonId,
        $cursoId,
        $jornada,
        $fecha,
        $horaEntrada,
        $limpiaEntrada
    );

    if (!$stmt->execute()) {
        error_log("Error ejecutar insertarBitacora: " . $stmt->error);
        return false;
    }

    return $conexion->insert_id;
}


// Bitácoras abiertas de un docente, pendientes de cierre y firma.
function listarBitacorasAbiertas($conexion, $profesorId)
{
    $sql = "SELECT b.BitacoraId, b.Fecha, b.HoraEntrada,
                   c.Nombre AS Curso, s.Nombre AS Salon,
                   r.NombreCompleto AS Responsable
            FROM bitacora b
            INNER JOIN curso c ON c.CursoId = b.CursoId
            INNER JOIN salon s ON s.SalonId = b.SalonId
            INNER JOIN usuario r ON r.UsuarioId = b.UsuarioResponsableId
            WHERE b.UsuarioProfesorId = ?
              AND b.EstadoRegistro = 'ABIERTA'
            ORDER BY b.Fecha DESC, b.HoraEntrada DESC";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return [];
    }

    $stmt->bind_param("i", $profesorId);
    $stmt->execute();

    return filasDe($stmt->get_result());
}


function obtenerBitacoraAbierta($conexion, $bitacoraId, $profesorId)
{
    $sql = "SELECT BitacoraId, Fecha, HoraEntrada
            FROM bitacora
            WHERE BitacoraId = ?
              AND UsuarioProfesorId = ?
              AND EstadoRegistro = 'ABIERTA'";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("ii", $bitacoraId, $profesorId);
    $stmt->execute();

    return $stmt->get_result()->fetch_assoc();
}


// Cierre: salida del salón, estado de limpieza y orden, y firma del docente.
function cerrarBitacora(
    $conexion,
    $bitacoraId,
    $profesorId,
    $horaSalida,
    $limpiaSalida,
    $ordenSalida,
    $observaciones,
    $fotoSalida,
    $fechaFirma
) {
    $sql = "UPDATE bitacora
            SET HoraSalida = ?,
                LimpiaSalida = ?,
                OrdenSalida = ?,
                Observaciones = ?,
                FotoSalida = ?,
                FechaFirma = ?,
                EstadoRegistro = 'FINALIZADA'
            WHERE BitacoraId = ?
              AND UsuarioProfesorId = ?
              AND EstadoRegistro = 'ABIERTA'";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        error_log("Error preparar cerrarBitacora: " . $conexion->error);
        return false;
    }

    $observaciones = $observaciones === "" ? null : $observaciones;

    $stmt->bind_param(
        "siisssii",
        $horaSalida,
        $limpiaSalida,
        $ordenSalida,
        $observaciones,
        $fotoSalida,
        $fechaFirma,
        $bitacoraId,
        $profesorId
    );

    if (!$stmt->execute()) {
        error_log("Error ejecutar cerrarBitacora: " . $stmt->error);
        return false;
    }

    return $stmt->affected_rows === 1;
}


function listarBitacorasMaestro($conexion)
{
    $sql = "SELECT b.BitacoraId, b.Fecha, b.HoraEntrada, b.HoraSalida,
                   s.Nombre AS Salon, c.Nombre AS Curso,
                   p.NombreCompleto AS Profesor,
                   r.NombreCompleto AS Responsable,
                   b.EstadoRegistro
            FROM bitacora b
            INNER JOIN salon s ON s.SalonId = b.SalonId
            INNER JOIN curso c ON c.CursoId = b.CursoId
            INNER JOIN usuario p ON p.UsuarioId = b.UsuarioProfesorId
            INNER JOIN usuario r ON r.UsuarioId = b.UsuarioResponsableId
            ORDER BY b.Fecha DESC, b.HoraEntrada DESC, b.BitacoraId DESC";

    $resultado = $conexion->query($sql);
    if (!$resultado) {
        error_log("No fue posible consultar el historial de bitácoras: " . $conexion->error);
        return false;
    }

    return filasDe($resultado);
}


function obtenerBitacoraMaestro($conexion, $bitacoraId)
{
    $sql = "SELECT BitacoraId, UsuarioProfesorId, UsuarioResponsableId,
                   SalonId, CursoId, Jornada, Fecha, HoraEntrada, HoraSalida,
                   LimpiaEntrada, LimpiaSalida, OrdenSalida, Observaciones,
                   FotoSalida, FechaFirma, EstadoRegistro
            FROM bitacora
            WHERE BitacoraId = ?";
    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("i", $bitacoraId);
    $stmt->execute();

    return $stmt->get_result()->fetch_assoc();
}


function existeSalon($conexion, $salonId)
{
    $stmt = $conexion->prepare("SELECT SalonId FROM salon WHERE SalonId = ?");

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("i", $salonId);
    $stmt->execute();

    return $stmt->get_result()->num_rows === 1;
}


function actualizarBitacoraMaestro(
    $conexion,
    $bitacoraId,
    $profesorId,
    $responsableId,
    $salonId,
    $curso,
    $jornada,
    $fecha,
    $horaEntrada,
    $horaSalida,
    $limpiaEntrada,
    $limpiaSalida,
    $ordenSalida,
    $observaciones
) {
    if (!$conexion->begin_transaction()) {
        return false;
    }

    $stmtExiste = $conexion->prepare("SELECT BitacoraId FROM bitacora WHERE BitacoraId = ? FOR UPDATE");
    if (!$stmtExiste) {
        $conexion->rollback();
        return false;
    }

    $stmtExiste->bind_param("i", $bitacoraId);
    if (!$stmtExiste->execute() || $stmtExiste->get_result()->num_rows !== 1) {
        $conexion->rollback();
        return false;
    }

    $cursoId = obtenerOCrearCurso($conexion, $curso);
    if ($cursoId === false) {
        $conexion->rollback();
        return false;
    }

    $sql = "UPDATE bitacora
            SET UsuarioProfesorId = ?, UsuarioResponsableId = ?, SalonId = ?,
                CursoId = ?, Jornada = ?, Fecha = ?, HoraEntrada = ?,
                HoraSalida = ?, LimpiaEntrada = ?, LimpiaSalida = ?,
                OrdenSalida = ?, Observaciones = ?
            WHERE BitacoraId = ?";
    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        $conexion->rollback();
        return false;
    }

    $observaciones = $observaciones === "" ? null : $observaciones;
    $stmt->bind_param(
        "iiiissssiiisi",
        $profesorId,
        $responsableId,
        $salonId,
        $cursoId,
        $jornada,
        $fecha,
        $horaEntrada,
        $horaSalida,
        $limpiaEntrada,
        $limpiaSalida,
        $ordenSalida,
        $observaciones,
        $bitacoraId
    );

    if (!$stmt->execute() || !$conexion->commit()) {
        $conexion->rollback();
        return false;
    }

    return true;
}


function eliminarBitacoraMaestro($conexion, $bitacoraId)
{
    $bitacora = obtenerBitacoraMaestro($conexion, $bitacoraId);
    if (!$bitacora || !$conexion->begin_transaction()) {
        return false;
    }

    $stmtEquipos = $conexion->prepare(
        "SELECT EquipoId FROM bitacora_equipo WHERE BitacoraId = ?"
    );
    if (!$stmtEquipos) {
        $conexion->rollback();
        return false;
    }

    $stmtEquipos->bind_param("i", $bitacoraId);
    if (!$stmtEquipos->execute()) {
        $conexion->rollback();
        return false;
    }

    $equipos = filasDe($stmtEquipos->get_result());
    $stmt = $conexion->prepare("DELETE FROM bitacora WHERE BitacoraId = ?");
    if (!$stmt) {
        $conexion->rollback();
        return false;
    }

    $stmt->bind_param("i", $bitacoraId);
    if (!$stmt->execute() || $stmt->affected_rows !== 1) {
        $conexion->rollback();
        return false;
    }

    foreach ($equipos as $equipo) {
        if (!sincronizarEstadoEquipo($conexion, (int) $equipo["EquipoId"])) {
            $conexion->rollback();
            return false;
        }
    }

    if (!$conexion->commit()) {
        $conexion->rollback();
        return false;
    }

    return $bitacora["FotoSalida"];
}


// Bitácoras a las que la persona puede asociar un reporte de daño: las que
// tiene abiertas (puede haber una por sala) y, si no tiene ninguna abierta,
// la más reciente que no esté anulada.
function listarBitacorasParaNovedad($conexion, $usuarioId)
{
    $base = "SELECT b.BitacoraId, b.SalonId, b.Fecha, b.EstadoRegistro,
                    c.Nombre AS Curso, s.Nombre AS Salon
             FROM bitacora b
             INNER JOIN curso c ON c.CursoId = b.CursoId
             INNER JOIN salon s ON s.SalonId = b.SalonId
             WHERE (b.UsuarioProfesorId = ? OR b.UsuarioResponsableId = ?)";

    $consultas = [
        $base . " AND b.EstadoRegistro = 'ABIERTA' ORDER BY b.BitacoraId DESC",
        $base . " AND b.EstadoRegistro = 'FINALIZADA' ORDER BY b.BitacoraId DESC LIMIT 1"
    ];

    foreach ($consultas as $sql) {
        $stmt = $conexion->prepare($sql);

        if (!$stmt) {
            return [];
        }

        $stmt->bind_param("ii", $usuarioId, $usuarioId);
        $stmt->execute();

        $filas = filasDe($stmt->get_result());

        if (count($filas) > 0) {
            return $filas;
        }
    }

    return [];
}


/* ------------------------------------------------------------------
 * EQUIPOS Y NOVEDADES
 * ------------------------------------------------------------------ */

// El código de inventario se repite entre salas (cada una tiene su PC-01),
// por eso siempre se busca dentro de la sala de la bitácora.
function buscarEquipoPorCodigo($conexion, $codigo, $salonId)
{
    $sql = "SELECT EquipoId
            FROM equipo
            WHERE CodigoInventario = ? AND SalonId = ?";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("si", $codigo, $salonId);
    $stmt->execute();

    return $stmt->get_result()->fetch_assoc();
}


function insertarEquipo($conexion, $codigo, $nombre, $salonId)
{
    $sql = "INSERT INTO equipo
            (CodigoInventario, NombreEquipo, Estado, SalonId)
            VALUES (?, ?, 'OPERATIVO', ?)";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("ssi", $codigo, $nombre, $salonId);

    return $stmt->execute() ? $conexion->insert_id : false;
}


function existeNovedad($conexion, $bitacoraId, $equipoId)
{
    $sql = "SELECT BitacoraId
            FROM bitacora_equipo
            WHERE BitacoraId = ? AND EquipoId = ?";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("ii", $bitacoraId, $equipoId);
    $stmt->execute();

    return $stmt->get_result()->num_rows > 0;
}


function insertarNovedad($conexion, $bitacoraId, $equipoId, $descripcion, $nivelDano)
{
    $sql = "INSERT INTO bitacora_equipo
            (BitacoraId, EquipoId, NivelDano, DescripcionFalla)
            VALUES (?, ?, ?, ?)";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("iiss", $bitacoraId, $equipoId, $nivelDano, $descripcion);

    if (!$stmt->execute()) {
        error_log("Error ejecutar insertarNovedad: " . $stmt->error);
        return false;
    }

    return true;
}


function listarNovedades($conexion)
{
    $sql = "SELECT
                be.BitacoraId,
                be.EquipoId,
                be.FechaReporte,
                e.CodigoInventario,
                s.Nombre AS Salon,
                be.NivelDano,
                be.DescripcionFalla,
                be.EstadoNovedad,
                c.Nombre AS Curso,
                p.NombreCompleto AS Profesor,
                t.NombreCompleto AS Tecnico
            FROM bitacora_equipo be
            INNER JOIN bitacora b ON b.BitacoraId = be.BitacoraId
            INNER JOIN equipo e ON e.EquipoId = be.EquipoId
            INNER JOIN salon s ON s.SalonId = e.SalonId
            INNER JOIN curso c ON c.CursoId = b.CursoId
            INNER JOIN usuario p ON p.UsuarioId = b.UsuarioProfesorId
            LEFT JOIN usuario t ON t.UsuarioId = be.TecnicoId
            ORDER BY be.FechaReporte DESC";

    return $conexion->query($sql);
}


// Si quien actualiza es un técnico, queda asignado a la novedad.
// Si es el administrador ($tecnicoId = null) se conserva el técnico actual.
function actualizarEstadoNovedad($conexion, $bitacoraId, $equipoId, $estado, $tecnicoId)
{
    $sql = "UPDATE bitacora_equipo
            SET EstadoNovedad = ?,
                TecnicoId = COALESCE(?, TecnicoId)
            WHERE BitacoraId = ? AND EquipoId = ?";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("siii", $estado, $tecnicoId, $bitacoraId, $equipoId);

    if (!$stmt->execute()) {
        error_log("Error ejecutar actualizarEstadoNovedad: " . $stmt->error);
        return false;
    }

    return true;
}


// Deja el estado del equipo acorde con sus novedades sin resolver:
// en revisión -> MANTENIMIENTO, daño grave o crítico -> DAÑADO,
// de lo contrario OPERATIVO. Los equipos dados de BAJA no se tocan.
function sincronizarEstadoEquipo($conexion, $equipoId)
{
    $sql = "UPDATE equipo e
            SET e.Estado = CASE
                WHEN EXISTS (
                    SELECT 1 FROM bitacora_equipo be
                    WHERE be.EquipoId = e.EquipoId
                      AND be.EstadoNovedad = 'En revisión'
                ) THEN 'MANTENIMIENTO'
                WHEN EXISTS (
                    SELECT 1 FROM bitacora_equipo be
                    WHERE be.EquipoId = e.EquipoId
                      AND be.EstadoNovedad <> 'Solucionado'
                      AND be.NivelDano IN ('Grave/Severo', 'Crítico/Urgente')
                ) THEN 'DAÑADO'
                ELSE 'OPERATIVO'
            END
            WHERE e.EquipoId = ? AND e.Estado <> 'BAJA'";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("i", $equipoId);

    return $stmt->execute();
}


/* ------------------------------------------------------------------
 * INDICADORES DEL PANEL
 * ------------------------------------------------------------------ */

// Equipos que hay en total en las salas (según su registro) y cuántos de
// ellos están dañados. Los disponibles son la diferencia.
function resumenEquiposSalas($conexion)
{
    $sql = "SELECT COALESCE(SUM(Cantidad), 0) AS total,
                   COALESCE(SUM(CantidadDanada), 0) AS danados
            FROM salon_inventario";

    $resultado = $conexion->query($sql);
    $fila = $resultado ? $resultado->fetch_assoc() : ["total" => 0, "danados" => 0];

    $total = (int) $fila["total"];
    $danados = (int) $fila["danados"];

    return [
        "total" => $total,
        "danados" => $danados,
        "disponibles" => $total - $danados
    ];
}


// Novedades sin solucionar, contadas por nivel de daño: [NivelDano => cantidad]
// (todos los niveles aparecen, aunque sea en cero).
function contarNovedadesPorNivel($conexion, $niveles)
{
    $conteo = array_fill_keys($niveles, 0);

    $sql = "SELECT NivelDano, COUNT(*) AS total
            FROM bitacora_equipo
            WHERE EstadoNovedad <> 'Solucionado'
            GROUP BY NivelDano";

    foreach (filasDe($conexion->query($sql)) as $fila) {
        $conteo[$fila["NivelDano"]] = (int) $fila["total"];
    }

    return $conteo;
}


/* ------------------------------------------------------------------
 * REGISTRO DE LAS SALAS
 * Cada sala guarda lo que contiene (PCs, teclados, mouse, televisores,
 * proyectores...) y si está limpia y organizada. Se edita cada cierto
 * tiempo y los docentes lo ven al abrir la bitácora.
 * ------------------------------------------------------------------ */

function listarTiposElemento($conexion)
{
    $sql = "SELECT TipoElementoId, Nombre
            FROM tipo_elemento
            ORDER BY TipoElementoId";

    return filasDe($conexion->query($sql));
}


function listarSalas($conexion)
{
    $sql = "SELECT s.SalonId, s.Nombre, s.Estado, s.Limpia, s.Organizada,
                   s.ObservacionesRegistro, s.FechaActualizacion,
                   u.NombreCompleto AS ActualizadoPor
            FROM salon s
            LEFT JOIN usuario u ON u.UsuarioId = s.UsuarioActualizacionId
            ORDER BY s.Nombre";

    return filasDe($conexion->query($sql));
}


// Inventario de todas las salas:
// [SalonId][TipoElementoId] => ["cantidad" => total, "danados" => dañados]
function inventarioSalas($conexion)
{
    $sql = "SELECT SalonId, TipoElementoId, Cantidad, CantidadDanada
            FROM salon_inventario";

    $inventario = [];

    foreach (filasDe($conexion->query($sql)) as $fila) {
        $inventario[(int) $fila["SalonId"]][(int) $fila["TipoElementoId"]] = [
            "cantidad" => (int) $fila["Cantidad"],
            "danados" => (int) $fila["CantidadDanada"]
        ];
    }

    return $inventario;
}


// Guarda (o corrige) el registro completo de la sala en una sola transacción.
function guardarRegistroSala(
    $conexion,
    $salonId,
    $cantidades,
    $danados,
    $limpia,
    $organizada,
    $observaciones,
    $usuarioId,
    $ahora
) {
    $observaciones = $observaciones === "" ? null : $observaciones;

    $conexion->begin_transaction();

    $stmt = $conexion->prepare(
        "UPDATE salon
         SET Limpia = ?,
             Organizada = ?,
             ObservacionesRegistro = ?,
             FechaActualizacion = ?,
             UsuarioActualizacionId = ?
         WHERE SalonId = ?"
    );

    if (!$stmt) {
        $conexion->rollback();
        return false;
    }

    $stmt->bind_param("iissii", $limpia, $organizada, $observaciones, $ahora, $usuarioId, $salonId);

    if (!$stmt->execute()) {
        error_log("Error guardarRegistroSala (salon): " . $stmt->error);
        $conexion->rollback();
        return false;
    }

    $stmt = $conexion->prepare(
        "INSERT INTO salon_inventario (SalonId, TipoElementoId, Cantidad, CantidadDanada)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE Cantidad = VALUES(Cantidad),
                                 CantidadDanada = VALUES(CantidadDanada)"
    );

    if (!$stmt) {
        $conexion->rollback();
        return false;
    }

    foreach ($cantidades as $tipoId => $cantidad) {
        $stmt->bind_param("iiii", $salonId, $tipoId, $cantidad, $danados[$tipoId]);

        if (!$stmt->execute()) {
            error_log("Error guardarRegistroSala (inventario): " . $stmt->error);
            $conexion->rollback();
            return false;
        }
    }

    return $conexion->commit();
}


/* ------------------------------------------------------------------
 * HISTORIAL Y PLANILLA
 * ------------------------------------------------------------------ */

function listarBitacorasRecientes($conexion)
{
    $sql = "SELECT b.BitacoraId, b.Fecha, b.HoraEntrada, b.HoraSalida,
                   s.Nombre AS Salon, c.Nombre AS Curso,
                   p.NombreCompleto AS Profesor,
                   r.NombreCompleto AS Responsable,
                   b.EstadoRegistro, b.FotoSalida
            FROM bitacora b
            INNER JOIN salon s ON s.SalonId = b.SalonId
            INNER JOIN curso c ON c.CursoId = b.CursoId
            INNER JOIN usuario p ON p.UsuarioId = b.UsuarioProfesorId
            INNER JOIN usuario r ON r.UsuarioId = b.UsuarioResponsableId
            ORDER BY b.Fecha DESC, b.HoraEntrada DESC
            LIMIT 30";

    return filasDe($conexion->query($sql));
}


function listarPlanillaMensual($conexion)
{
    $sql = "SELECT b.Fecha, b.HoraEntrada, b.HoraSalida,
                   p.NombreCompleto AS Profesor,
                   r.NombreCompleto AS Responsable,
                   c.Nombre AS Curso, s.Nombre AS Salon, b.Jornada,
                   b.LimpiaEntrada, b.LimpiaSalida, b.OrdenSalida,
                   b.EstadoRegistro
            FROM bitacora b
            INNER JOIN usuario p ON p.UsuarioId = b.UsuarioProfesorId
            INNER JOIN usuario r ON r.UsuarioId = b.UsuarioResponsableId
            INNER JOIN curso c ON c.CursoId = b.CursoId
            INNER JOIN salon s ON s.SalonId = b.SalonId
            WHERE YEAR(b.Fecha) = YEAR(CURDATE())
              AND MONTH(b.Fecha) = MONTH(CURDATE())
            ORDER BY b.Fecha, b.HoraEntrada";

    return $conexion->query($sql);
}
