<?php
session_start();

$mensaje = $_GET["mensaje"] ?? "";
$vista = $_GET["vista"] ?? (isset($_SESSION["usuario_id"]) ? "bitacora" : "inicio");

require_once __DIR__ . "/config/conexionBDD.php";
require_once __DIR__ . "/datos/goss/gossDAO.php";
require_once __DIR__ . "/logica/validarGoss.php";

if (!isset($_SESSION["usuario_id"])) {
    if ($vista === "registro") {
        $roles = listarRoles($conexion);
    }
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>GOSS - Gestión de Bitácora Digital</title>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Oswald:wght@500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="vistas/estilos.css">
    </head>
    <body>
        <div class="bg-fixed"></div>
        <div class="overlay-gradient"></div>
        <img src="vistas/img/sena-logo.png" class="sena-watermark" alt="Logo SENA">
        <main class="contenido">
            <?php if ($mensaje !== ""): ?>
                <div class="alert"><?= htmlspecialchars($mensaje) ?></div>
            <?php endif; ?>
            <?php
            if ($vista === "maestro") {
                require __DIR__ . "/vistas/loginMaestro.php";
            } elseif ($vista === "login" || $vista === "registro") {
                require __DIR__ . "/vistas/" . $vista . ".php";
            } else {
                require __DIR__ . "/vistas/bienvenida.php";
            }
            ?>
        </main>
        <?php require __DIR__ . "/vistas/pie.php"; ?>
        <script src="vistas/goss.js"></script>
    </body>
    </html>
    <?php
    exit();
}

$rol = $_SESSION["rol"];
$usuarioId = (int) $_SESSION["usuario_id"];

// El privilegio maestro se consulta en la BD en cada petición; no depende solo de la sesión.
$stmtMaestro = $conexion->prepare(
    "SELECT u.EsMaestro, u.EstadoCuenta, u.NombreCompleto, r.NombreRol
     FROM usuario u
     INNER JOIN roles r ON r.RolId = u.RolId
     WHERE u.UsuarioId = ?"
);
$stmtMaestro->bind_param("i", $usuarioId);
$stmtMaestro->execute();
$estadoSesion = $stmtMaestro->get_result()->fetch_assoc();
if (!$estadoSesion || $estadoSesion["EstadoCuenta"] !== "ACTIVO") {
    $_SESSION = [];
    session_destroy();
    header("Location: index.php?vista=login&mensaje=" . urlencode("La cuenta no está habilitada."));
    exit();
}
$rol = $estadoSesion["NombreRol"];
$_SESSION["rol"] = $rol;
$_SESSION["nombre"] = $estadoSesion["NombreCompleto"];
$esMaestro = (int) $estadoSesion["EsMaestro"] === 1;
$_SESSION["es_maestro"] = $esMaestro ? 1 : 0;

// El administrador maestro solo puede entrar con sesión autenticada y bandera exclusiva en BD.
if ($vista === "maestro" && !$esMaestro) {
    http_response_code(404);
    $vista = "bitacora";
}
// Cada vista recibe solo los datos que necesita. Si la vista pedida no
// existe o el rol no tiene acceso, se muestra la bitácora.
if ($vista === "maestro" && $esMaestro) {
    $usuarios = listarUsuarios($conexion);
    $roles = filasDe(listarRoles($conexion));
    $usuarioEditar = null;
    $bitacorasMaestro = listarBitacorasMaestro($conexion);
    if ($bitacorasMaestro === false) {
        $mensaje = "No fue posible cargar el registro de bitácoras.";
    }
    $bitacoraEditar = null;
    $profesores = filasDe(listarUsuariosPorRol($conexion, ["Profesor"]));
    $responsables = filasDe(listarUsuariosPorRol($conexion, ["Tecnico", "Administrador"]));
    $salasMaestro = listarSalas($conexion);

    if (isset($_GET["editar"])) {
        $editarId = filter_var($_GET["editar"], FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]]);
        if ($editarId !== false && $editarId !== $usuarioId) {
            $usuarioEditar = obtenerUsuarioEditable($conexion, $editarId);
        }

        if (!$usuarioEditar || (int) $usuarioEditar["EsMaestro"] === 1) {
            $usuarioEditar = null;
            $mensaje = "Esa cuenta no se puede editar.";
        }
    }

    if (isset($_GET["editar_bitacora"])) {
        $editarBitacoraId = filter_var($_GET["editar_bitacora"], FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]]);
        if ($editarBitacoraId !== false) {
            $bitacoraEditar = obtenerBitacoraMaestro($conexion, $editarBitacoraId);
        }

        if (!$bitacoraEditar) {
            $mensaje = "No se encontró la bitácora que quieres editar.";
        }
    }
} elseif ($vista === "admin" && in_array($rol, ["Administrador", "Tecnico"], true)) {
    $novedades = listarNovedades($conexion);
    $equiposSalas = resumenEquiposSalas($conexion);
    $novedadesPorNivel = contarNovedadesPorNivel($conexion, array_keys(nivelesDano()));

    if ($rol === "Administrador") {
        $bitacorasRecientes = listarBitacorasRecientes($conexion);
    }
} elseif (in_array($vista, ["salas", "sala"], true) && in_array($rol, ["Administrador", "Tecnico"], true)) {
    $tiposElemento = listarTiposElemento($conexion);
    $salas = listarSalas($conexion);
    $inventarioSalas = inventarioSalas($conexion);

    if ($vista === "sala") {
        $salaActual = null;

        foreach ($salas as $sala) {
            if ((int) $sala["SalonId"] === (int) ($_GET["id"] ?? 0)) {
                $salaActual = $sala;
            }
        }

        // Si la sala pedida no existe, se vuelve al listado.
        if ($salaActual === null) {
            $vista = "salas";
        }
    }
} elseif ($vista === "usuarios" && $rol === "Administrador") {
    $usuarios = listarUsuarios($conexion);
} elseif ($vista === "novedad") {
    $bitacorasNovedad = listarBitacorasParaNovedad($conexion, $usuarioId);
} else {
    $vista = "bitacora";
    $cursos = listarCursos($conexion);
    $salas = listarSalas($conexion);
    $inventarioSalas = inventarioSalas($conexion);
    $participantes = listarUsuariosPorRol(
        $conexion,
        $rol === "Profesor" ? ["Tecnico", "Administrador"] : ["Profesor"]
    );

    $tiposElemento = listarTiposElemento($conexion);

    if ($rol === "Profesor") {
        $bitacorasAbiertas = listarBitacorasAbiertas($conexion, $usuarioId);
        $firmaActual = obtenerFirmaUsuario($conexion, $usuarioId);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GOSS - Gestión de Bitácora Digital</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Oswald:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="vistas/estilos.css">
</head>
<body>
    <div class="bg-fixed"></div>
    <div class="overlay-gradient"></div>
    <img src="vistas/img/sena-logo.png" class="sena-watermark" alt="Logo SENA">

    <?php require __DIR__ . "/vistas/nav.php"; ?>

    <main class="contenido con-nav">
        <?php if ($mensaje !== ""): ?>
            <div class="alert"><?= htmlspecialchars($mensaje) ?></div>
        <?php endif; ?>

        <?php require __DIR__ . "/vistas/" . $vista . ".php"; ?>
    </main>

    <?php require __DIR__ . "/vistas/pie.php"; ?>

    <script src="vistas/goss.js"></script>
</body>
</html>
